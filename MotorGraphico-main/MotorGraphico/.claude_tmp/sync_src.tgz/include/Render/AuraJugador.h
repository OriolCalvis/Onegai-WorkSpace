// PERGAMINO-01 — El aura de la moral a los pies del jugador.
//
// Oriol (29/09): la moral sale del HUD y se ve en el aspecto del avatar. La
// regla (que tramo, que color, donde va cada particula) es Game/AuraMoral;
// esto la dibuja en el pase de sombras del IsometricRenderer, bajo todos los
// sprites, como una sombra blob con color: halo dorado que se suma a la luz
// para el heroe y el justo, humo rojo oscuro que tapa para el canalla y el
// villano. Las motas de luz del heroe suben por delante del sprite.
// MORAL-01 (Oriol, 08/10): siete tramos; el heroe y el villano llevan alas
// (celestiales o demoniacas) detras del sprite, y el villano, motas de sombra.
//
// Reutiliza la textura radial de la sombra blob (BlobShadow.h): el color lo
// pone el tinte. Sigue al jugador por su posicion visible (casilla + paso
// interpolado), no por la logica: el aura no se adelanta al sprite.
//
// ESTETICA-01: tambien el brillo del equipo puesto (Game/Personajes/
// BrilloEquipo): el halo, que late y suma luz encima del sprite con el mismo
// frame que este, y los destellos y particulas de cada pieza, pixel a pixel.
#pragma once

#include <chrono>
#include <vector>

#include "Game/AuraMoral.h"
#include "Game/Personajes/BrilloEquipo.h"
#include "Render/IRenderable.h"

class Entity;
class HojaPersonaje;
class Texture;

class AuraJugador final : public IRenderable {
public:
    AuraJugador(const Entity* jugador, int anchoBaldosa, int altoBaldosa);

    // Recalcula el aspecto con el valor de la moral (-100..100).
    void ponMoral(int valor) { m_aspecto = Game::aspectoAura(valor); }
    const Game::AspectoAura& aspecto() const { return m_aspecto; }

    // ESTETICA-01: la hoja del jugador (con su brillo) y una textura blanca de
    // 1x1 para las particulas. nullptr = sin brillo. No propietario.
    void ponBrillo(const HojaPersonaje* hoja, Texture* blanco) {
        m_hoja = hoja;
        m_blanco = blanco;
    }

    void render(SpriteBatch& batch) override;
    void renderShadow(SpriteBatch& batch, Texture* texturaSombra) override;
    // Justo despues del jugador: las motas quedan por delante de su sprite.
    int getSortKey() const override;

private:
    const Entity* m_jugador;  // no propietario: el Player de Application
    int m_anchoBaldosa;
    int m_altoBaldosa;
    Game::AspectoAura m_aspecto;
    Texture* m_textura = nullptr;  // la de la sombra blob (la recibe renderShadow)
    std::chrono::steady_clock::time_point m_inicio = std::chrono::steady_clock::now();
    const HojaPersonaje* m_hoja = nullptr;  // ESTETICA-01
    Texture* m_blanco = nullptr;
    std::vector<Game::Destello> m_destellos;  // se reusa cada fotograma

    void renderMotas(SpriteBatch& batch, float segundos);
    void renderBrillo(SpriteBatch& batch, float segundos);
    void renderAlas(SpriteBatch& batch, float segundos);  // MORAL-01
};
