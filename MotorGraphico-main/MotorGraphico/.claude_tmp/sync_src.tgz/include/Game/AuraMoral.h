// PERGAMINO-01 — La moral, vista en el avatar del jugador.
//
// Decision de Oriol (29/09/2026): la moral sale del HUD y se refleja en el
// aspecto del avatar. MORAL-01 (Oriol, 08/10/2026, en «Boundington:
// alternativas, karma y moral»): siete tramos, cada uno con su aspecto:
//
//   Héroe (+75)        halo grande y alas celestiales con motas de luz
//   Salvador (+60)     halo grande
//   Respetado (+20)    halo tenue
//   Neutral            nada
//   Canalla (−20)      humo rojo oscuro a los pies
//   Desgraciado (−60)  humo espeso y el sprite en sombra
//   Villano (−75)      halo grande y alas demoníacas con motas de sombra
//
// La intensidad crece dentro de cada tramo, para que la moral se lea aunque
// no cambie de nombre. Los tramos son los de Morality (moral::tramoDe).
//
// Esto es la regla, sin OpenGL y sin reloj propio: dado el valor de la moral
// y un instante, dice que color, cuanto brilla y donde esta cada particula y
// cada pluma. Lo dibuja Render/AuraJugador.
#pragma once

#include "Core/Math/Vector4.h"
#include "Game/Morality.h"

namespace Game {

using TramoMoral = moral::Tramo;
TramoMoral tramoMoral(int valor);

enum class Alas { Ninguna, Celestiales, Demoniacas };

struct AspectoAura {
    TramoMoral tramo = TramoMoral::Neutral;
    bool visible = false;
    bool luz = false;             // true: brillo que se suma (halo); false: humo o sombra que tapa
    Vector4 color{0, 0, 0, 0};    // color del halo o del humo
    float intensidad = 0.0f;      // 0..1 dentro del tramo
    float radio = 0.0f;           // ancho del halo en baldosas (1 = 64 px)
    int particulas = 0;           // motas (heroe, villano) o volutas (canalla, desgraciado)
    bool motas = false;           // MORAL-01: las particulas suben (de luz o de sombra), por delante
    Alas alas = Alas::Ninguna;    // MORAL-01
    Vector4 colorAlas{0, 0, 0, 0};
    Vector4 tinteSprite{1, 1, 1, 1};  // multiplica el sprite del jugador
};

AspectoAura aspectoAura(int valorMoral);

// Una particula en el instante `segundos`, relativa a los pies: dx/dy en
// fracciones de baldosa (dy negativo = sube), radio en baldosas y alfa.
struct ParticulaAura {
    float dx = 0.0f, dy = 0.0f, radio = 0.0f, alfa = 0.0f;
};
ParticulaAura particulaAura(const AspectoAura& aspecto, int indice, float segundos);

// MORAL-01 — Una pluma de un ala: un cuadrilatero (arriba-izquierda,
// arriba-derecha, abajo-derecha, abajo-izquierda, como SpriteBatch::submitQuad)
// en fracciones del ancho del sprite, con el origen en los hombros (x a la
// derecha, y hacia abajo). lado: -1 el ala izquierda, +1 la derecha. Baten
// despacio (periodo de 2,6 s).
struct PlumaAla {
    float x[4] = {0, 0, 0, 0};
    float y[4] = {0, 0, 0, 0};
    float alfa = 0.0f;
};
constexpr int kPlumasPorAla = 5;
PlumaAla plumaAla(const AspectoAura& aspecto, int lado, int indice, float segundos);

// Pulso lento del halo (0,85..1,0), periodo de 2,4 s.
float pulsoAura(float segundos);

}  // namespace Game
