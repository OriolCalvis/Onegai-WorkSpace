// PERGAMINO-01 — ver include/Render/AuraJugador.h.
#include "Render/AuraJugador.h"

#include <algorithm>
#include <cmath>
#include <utility>

#include "Core/Math/IsoMath.h"
#include "Core/Resources/TextureAtlas.h"
#include "Render/Entity.h"
#include "Render/HojaPersonaje.h"
#include "Render/PintaDestellos.h"
#include "Render/SpriteBatch.h"

#include <glad/glad.h>

// El halo suma luz (el suelo se aclara); el humo, no (Render::MezclaAditiva, PintaDestellos.h).
using Render::MezclaAditiva;

AuraJugador::AuraJugador(const Entity* jugador, int anchoBaldosa, int altoBaldosa)
    : m_jugador(jugador), m_anchoBaldosa(anchoBaldosa), m_altoBaldosa(altoBaldosa) {}

int AuraJugador::getSortKey() const { return m_jugador != nullptr ? m_jugador->getSortKey() + 1 : 0; }

void AuraJugador::renderShadow(SpriteBatch& batch, Texture* texturaSombra) {
    m_textura = texturaSombra;
    if (m_jugador == nullptr || texturaSombra == nullptr || !m_aspecto.visible) return;
    const float tw = static_cast<float>(m_anchoBaldosa), th = static_cast<float>(m_altoBaldosa);
    const Vector2 base = IsoMath::gridToScreen(m_jugador->gridPosition(), tw, th) + m_jugador->offset();
    // Los pies: donde Entity::renderShadow apoya la sombra blob.
    const Vector2 pies{base.x + tw * 0.5f, base.y + th * 0.9f};
    const float t = std::chrono::duration<float>(std::chrono::steady_clock::now() - m_inicio).count();
    const UVRect entera{0.0f, 0.0f, 1.0f, 1.0f};
    if (m_aspecto.luz) {
        const MezclaAditiva aditiva(batch);
        const float pulso = Game::pulsoAura(t);
        const float w = tw * m_aspecto.radio * pulso, h = th * 0.9f * m_aspecto.radio * pulso;
        Vector4 c = m_aspecto.color;
        c.w = 0.55f * m_aspecto.intensidad;
        batch.submit(Vector2{pies.x - w * 0.5f, pies.y - h * 0.5f}, Vector2{w, h}, entera, texturaSombra, c);
        // Un nucleo mas pequeno y brillante: se lee como luz, no como mancha.
        c.w = 0.45f * m_aspecto.intensidad;
        batch.submit(Vector2{pies.x - w * 0.28f, pies.y - h * 0.28f}, Vector2{w * 0.56f, h * 0.56f}, entera,
                     texturaSombra, c);
        renderAlas(batch, t);  // MORAL-01: las del heroe, detras del sprite
        return;
    }
    // Humo (o el halo oscuro del villano): una mancha base y volutas que
    // rondan los pies. Las motas de sombra del villano van por delante.
    Vector4 c = m_aspecto.color;
    c.w = 0.5f * m_aspecto.intensidad;
    const float w = tw * 0.9f * m_aspecto.radio, h = th * 0.8f * m_aspecto.radio;
    batch.submit(Vector2{pies.x - w * 0.5f, pies.y - h * 0.5f}, Vector2{w, h}, entera, texturaSombra, c);
    renderAlas(batch, t);
    for (int i = 0; i < (m_aspecto.motas ? 0 : m_aspecto.particulas); ++i) {
        const Game::ParticulaAura p = Game::particulaAura(m_aspecto, i, t);
        if (p.alfa <= 0.0f) continue;
        const float r = p.radio * tw;
        Vector4 cv = m_aspecto.color;
        cv.w = p.alfa;
        batch.submit(Vector2{pies.x + p.dx * tw - r, pies.y + p.dy * th - r * 0.6f}, Vector2{2.0f * r, 1.2f * r},
                     entera, texturaSombra, cv);
    }
}

void AuraJugador::render(SpriteBatch& batch) {
    const float t = std::chrono::duration<float>(std::chrono::steady_clock::now() - m_inicio).count();
    renderBrillo(batch, t);
    renderMotas(batch, t);
}

void AuraJugador::renderBrillo(SpriteBatch& batch, float t) {
    if (m_jugador == nullptr || m_hoja == nullptr || m_blanco == nullptr || m_hoja->brillo().vacia())
        return;
    Vector2 esquina, tam;
    int region = 0;
    if (!m_jugador->dibujoDePersonaje(esquina, tam, region))
        return;
    // El halo: el mismo frame que el sprite, sumando luz, con su latido.
    if (TextureAtlas* atlas = m_hoja->atlasBrillo()) {
        const MezclaAditiva aditiva(batch);
        UVRect uv = atlas->getUVInset(region, 1.0f);
        std::swap(uv.v0, uv.v1);  // como Entity::render (la hoja se sube de abajo arriba)
        batch.submit(esquina, tam, uv, atlas->texture(),
                     Vector4{1.0f, 1.0f, 1.0f, Game::latidoDeBrillo(m_hoja->brillo(), t)});
    }
    // Destellos, barrido y particulas: pixeles del frame, a la escala del sprite (PART-02d: la misma
    // pintura que las cartas jugadas, Render::pintaDestellos).
    m_destellos.clear();
    Game::destellosDeBrillo(m_hoja->brillo(), region, t, m_destellos);
    Render::pintaDestellos(batch, m_destellos, esquina, tam, m_blanco);
}

void AuraJugador::renderMotas(SpriteBatch& batch, float t) {
    // Las motas van por delante del sprite: las de luz del heroe, que suman, y
    // (MORAL-01) las de sombra del villano, que tapan.
    if (m_jugador == nullptr || m_textura == nullptr || !m_aspecto.visible || !(m_aspecto.luz || m_aspecto.motas) ||
        m_aspecto.particulas == 0)
        return;
    const float tw = static_cast<float>(m_anchoBaldosa), th = static_cast<float>(m_altoBaldosa);
    const Vector2 base = IsoMath::gridToScreen(m_jugador->gridPosition(), tw, th) + m_jugador->offset();
    const Vector2 pies{base.x + tw * 0.5f, base.y + th * 0.9f};
    const auto pinta = [&](const Vector4& color) {
        for (int i = 0; i < m_aspecto.particulas; ++i) {
            const Game::ParticulaAura p = Game::particulaAura(m_aspecto, i, t);
            if (p.alfa <= 0.0f) continue;
            const float r = p.radio * tw;
            Vector4 c = color;
            c.w = p.alfa;
            batch.submit(Vector2{pies.x + p.dx * tw - r, pies.y + p.dy * th * 2.0f - r}, Vector2{2.0f * r, 2.0f * r},
                         UVRect{0.0f, 0.0f, 1.0f, 1.0f}, m_textura, c);
        }
    };
    if (m_aspecto.luz) {
        const MezclaAditiva aditiva(batch);
        pinta(Vector4{1.0f, 0.92f, 0.62f, 1.0f});
    } else {
        pinta(Vector4{0.07f, 0.0f, 0.02f, 1.0f});
    }
}

void AuraJugador::renderAlas(SpriteBatch& batch, float t) {
    // MORAL-01 — Las alas, en el pase de sombras: detras del sprite. Cada pluma
    // es la mancha radial de la sombra estirada en un cuadrilatero.
    if (m_jugador == nullptr || m_textura == nullptr || m_aspecto.alas == Game::Alas::Ninguna) return;
    const float tw = static_cast<float>(m_anchoBaldosa), th = static_cast<float>(m_altoBaldosa);
    Vector2 esquina, tam;
    int region = 0;
    Vector2 hombros;
    float escala = tw;
    if (m_jugador->dibujoDePersonaje(esquina, tam, region)) {
        hombros = Vector2{esquina.x + tam.x * 0.5f, esquina.y + tam.y * 0.45f};
        escala = tam.x;
    } else {
        const Vector2 base = IsoMath::gridToScreen(m_jugador->gridPosition(), tw, th) + m_jugador->offset();
        hombros = Vector2{base.x + tw * 0.5f, base.y + th * 0.9f - th * 1.7f};
    }
    const Vector2 uv[4] = {Vector2{0.0f, 0.0f}, Vector2{1.0f, 0.0f}, Vector2{1.0f, 1.0f}, Vector2{0.0f, 1.0f}};
    const auto pinta = [&]() {
        for (const int lado : {-1, 1})
            for (int i = 0; i < Game::kPlumasPorAla; ++i) {
                const Game::PlumaAla p = Game::plumaAla(m_aspecto, lado, i, t);
                Vector2 e[4];
                for (int k = 0; k < 4; ++k) e[k] = Vector2{hombros.x + p.x[k] * escala, hombros.y + p.y[k] * escala};
                Vector4 c = m_aspecto.colorAlas;
                c.w = p.alfa;
                batch.submitQuad(e, uv, m_textura, c);
            }
    };
    if (m_aspecto.alas == Game::Alas::Celestiales) {
        const MezclaAditiva aditiva(batch);
        pinta();
    } else {
        pinta();
    }
}
