#include "Editor/ProjectHub.h"

#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <string>
#include <vector>

// popen/pclose son POSIX; en Windows llevan guion bajo. El motor no tiene
// hoy una capa de plataforma, asi que el arreglo va aqui y no se inventa
// una abstraccion para dos nombres.
#if defined(_WIN32)
#define ABRIR_TUBERIA _popen
#define CERRAR_TUBERIA _pclose
#else
#define ABRIR_TUBERIA popen
#define CERRAR_TUBERIA pclose
#endif

namespace Editor {
namespace {

// Rellena a la derecha hasta 'ancho'. El HUD usa una fuente de ancho fijo
// (BitmapFont), asi que alinear con espacios da columnas de verdad.
std::string col(const std::string& s, std::size_t ancho) {
    std::string r = s.substr(0, ancho);
    r.resize(ancho, ' ');
    return r;
}

std::string num(int n, std::size_t ancho) {
    std::string s = std::to_string(n);
    return std::string(ancho > s.size() ? ancho - s.size() : 0, ' ') + s;
}

// Un id que va a acabar en una linea de shell. ProjectIndex::create() ya
// lo obliga, pero un manifiesto se puede editar a mano y el id de dentro
// mandar sobre el del fichero, asi que no se da por bueno.
bool idSeguro(const std::string& s) {
    if (s.empty()) {
        return false;
    }
    for (char c : s) {
        const bool ok = (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '_';
        if (!ok) {
            return false;
        }
    }
    return true;
}

// El editor se puede ejecutar desde la raiz del repositorio o desde build/.
// El primer caso ve tools/ directamente; el segundo tiene assets/ copiados
// pero el script sigue dos niveles por encima. No asumir el directorio de
// trabajo evita que el boton Build diga que todo fue bien en la consola pero
// no encuentre el empaquetador.
std::string rutaBuildProyecto(const std::string& assetsRoot) {
    // Subir hacia arriba desde el directorio actual: el editor se ejecuta
    // desde la raiz del repo, desde build/ (un nivel) y desde
    // out/build/<preset> (tres niveles, los presets de CMake). La lista
    // fija de candidatos solo cubria los dos primeros fondos, y desde un
    // preset el boton de empaquetar decia "no se encontro el script".
    std::vector<std::string> candidatas;
    std::string subiendo = ".";
    for (int i = 0; i < 6; ++i) {
        candidatas.push_back(subiendo + "/tools/build_proyecto.py");
        subiendo += "/..";
    }
    // Y por si el cwd no tiene nada que ver, relativas a los assets.
    candidatas.push_back(assetsRoot + "/../tools/build_proyecto.py");
    candidatas.push_back(assetsRoot + "/../../tools/build_proyecto.py");
    for (const std::string& ruta : candidatas) {
        std::ifstream f(ruta);
        if (f.good()) {
            return ruta;
        }
    }
    return {};
}

// H4-01 — El informe de duplicate() se devuelve y no se imprime «porque
// quien duplica tiene que poder ensenarlo» (lo dice ProjectIndex.h). Este
// es el sitio donde se ensena. Las listas se recortan como en detail():
// un proyecto con 40 niveles copiados no cabe en el panel, y el numero ya
// dice lo que hace falta saber antes de ponerse a editar la copia.
std::string textoInforme(const ProjectIndex::DuplicateReport& r) {
    std::string t = "id '" + r.project.id + "'";
    if (!r.project.prefix.empty()) {
        t += ", prefijo " + r.project.prefix;
    }
    t += "\n";
    const std::size_t kMax = 6;
    t += "Copiados " + std::to_string(r.copied.size()) +
         " (llevaban el prefijo del original: editarlos no lo toca):\n";
    for (std::size_t i = 0; i < r.copied.size() && i < kMax; ++i) {
        t += "  " + r.copied[i] + "\n";
    }
    if (r.copied.size() > kMax) {
        t += "  ...y " + std::to_string(r.copied.size() - kMax) + " mas\n";
    }
    if (r.shared.empty()) {
        t += "Compartidos 0: la copia no apunta a nada del original.";
        return t;
    }
    t += "Compartidos " + std::to_string(r.shared.size()) +
         " (no eran del original: se referencian igual, no se copian):\n";
    for (std::size_t i = 0; i < r.shared.size() && i < kMax; ++i) {
        t += "  " + r.shared[i] + "\n";
    }
    if (r.shared.size() > kMax) {
        t += "  ...y " + std::to_string(r.shared.size() - kMax) + " mas";
    }
    return t;
}

}  // namespace

Result<ProjectHub> ProjectHub::load(const std::string& assetsRoot) {
    auto r = ProjectIndex::scan(assetsRoot);
    if (!r.isOk()) {
        return Result<ProjectHub>::Error(r.errorMessage());
    }
    ProjectHub h;
    h.m_index = r.value();
    h.m_root = assetsRoot;
    h.rebuildLines();
    return Result<ProjectHub>::Ok(std::move(h));
}

void ProjectHub::rebuildLines() {
    m_lines.clear();
    for (const Project& p : m_index.projects()) {
        const ProjectCheck c = m_index.check(p.id);
        // "jugable" y "completo" no son lo mismo y la diferencia importa:
        // un pack sin aventura se edita igual, solo que no arranca.
        const char* estado = c.ok()
                                 ? (p.entryKind == Project::EntryKind::Adventure ? "listo" : "sin historia")
                                 : "con avisos";
        m_lines.push_back(col(p.name, 30) + " " + num((int)p.levels.size(), 4) +
                          " niv " + num((int)p.adventures.size(), 2) + " av   " + estado);
    }
    if (m_selected >= m_lines.size()) {
        m_selected = m_lines.empty() ? 0 : m_lines.size() - 1;
    }
}

const Project* ProjectHub::current() const {
    if (m_selected >= m_index.size()) {
        return nullptr;
    }
    return &m_index.projects()[m_selected];
}

void ProjectHub::moveUp() {
    if (m_index.size() == 0) {
        return;
    }
    // Da la vuelta: con cinco proyectos, llegar al ultimo desde el primero
    // no deberia costar cuatro pulsaciones.
    m_selected = (m_selected == 0) ? m_index.size() - 1 : m_selected - 1;
}

void ProjectHub::moveDown() {
    if (m_index.size() == 0) {
        return;
    }
    m_selected = (m_selected + 1) % m_index.size();
}

std::vector<std::string> ProjectHub::detail() const {
    std::vector<std::string> d;
    const Project* p = current();
    if (p == nullptr) {
        d.push_back("No hay ningun proyecto en assets/proyectos.");
        d.push_back("Pulsa N para crear el primero.");
        return d;
    }
    d.push_back(p->name);
    if (!p->epoch.empty()) {
        d.push_back("epoca:  " + p->epoch);
    }
    if (!p->author.empty()) {
        d.push_back("autor:  " + p->author);
    }
    d.push_back("id:     " + p->id + (p->prefix.empty() ? "" : "   prefijo " + p->prefix));
    d.push_back("");
    d.push_back("niveles " + std::to_string(p->levels.size()) +
                "   mapas " + std::to_string(p->maps.size()) +
                "   aventuras " + std::to_string(p->adventures.size()) +
                "   catalogos " + std::to_string(p->catalogs.size()));
    // Decir SOLO el nombre del fichero esconde el problema que tuvimos:
    // 'entrada' se relleno de dos formas distintas y una no resolvia. Aqui
    // se dice a que resolvio de verdad, no lo que pone el manifiesto.
    switch (p->entryKind) {
        case Project::EntryKind::None:
            d.push_back("arranque: (ninguno) - se puede editar, no jugar");
            break;
        case Project::EntryKind::Adventure:
            d.push_back("arranque: aventura " + p->entryPath);
            break;
        case Project::EntryKind::Level:
            d.push_back("arranque: nivel " + p->entryPath + "  (sin historia)");
            break;
        case Project::EntryKind::Missing:
            d.push_back("arranque: '" + p->entry + "' NO SE ENCUENTRA");
            break;
    }
    const ProjectCheck c = m_index.check(p->id);
    if (!c.ok()) {
        d.push_back("");
        // Solo los primeros: si a un pack le faltan 40 ficheros, la lista
        // entera tapa la pantalla y no ayuda mas que saber que faltan.
        for (std::size_t i = 0; i < c.problems.size() && i < 6; ++i) {
            d.push_back("! " + c.problems[i]);
        }
        if (c.problems.size() > 6) {
            d.push_back("! ...y " + std::to_string(c.problems.size() - 6) + " mas");
        }
    }
    return d;
}

void ProjectHub::setMessage(bool ok, const std::string& titulo, const std::string& cuerpo) {
    m_lastOk = ok;
    m_message.clear();
    m_message.push_back(titulo);
    std::string linea;
    for (char c : cuerpo) {
        if (c == '\n') {
            m_message.push_back(linea);
            linea.clear();
        } else if (c != '\r') {
            linea += c;
        }
    }
    if (!linea.empty()) {
        m_message.push_back(linea);
    }
    m_mode = Mode::Message;
}

void ProjectHub::seleccionar(const std::string& id) {
    for (std::size_t i = 0; i < m_index.size(); ++i) {
        if (m_index.projects()[i].id == id) {
            m_selected = i;
        }
    }
}

void ProjectHub::refresh() {
    auto r = ProjectIndex::scan(m_root);
    if (r.isOk()) {
        m_index = r.value();
        rebuildLines();
    }
}

void ProjectHub::build() {
    const Project* p = current();
    if (p == nullptr) {
        setMessage(false, "No hay proyecto que compilar", "");
        return;
    }
    if (!idSeguro(p->id)) {
        setMessage(false, "Id no valido: '" + p->id + "'",
                   "Solo [a-z0-9_]. Revisa el manifiesto a mano.");
        return;
    }
    const std::string script = rutaBuildProyecto(m_root);
    if (script.empty()) {
        setMessage(false, "No se encontro tools/build_proyecto.py",
                   "Ejecuta el editor desde el repositorio o desde build/ con el arbol fuente al lado.");
        return;
    }
    const std::string cmd = "python3 " + script + " " + p->id + " 2>&1";
    std::FILE* tuberia = ABRIR_TUBERIA(cmd.c_str(), "r");
    if (tuberia == nullptr) {
        setMessage(false, "No se pudo lanzar el empaquetado",
                   "Hace falta python3 en el PATH.\n" + cmd);
        return;
    }
    std::string salida;
    char buf[512];
    while (std::fgets(buf, sizeof(buf), tuberia) != nullptr) {
        salida += buf;
    }
    // pclose devuelve el estado de espera, no el codigo de salida: el
    // script devuelve 1 si algun proyecto no quedo jugable, y eso hay que
    // poder distinguirlo de "fue bien".
    const int estado = CERRAR_TUBERIA(tuberia);
    const bool ok = (estado == 0);
    setMessage(ok, ok ? "Build de '" + p->id + "' lista en builds/" + p->id + "/"
                      : "El empaquetado de '" + p->id + "' termino con avisos",
               salida);
}

ProjectHub::Action ProjectHub::key(char k) {
    // --- Escribiendo: el id de un proyecto nuevo, o el nombre de la copia ---
    if (m_mode == Mode::NewProject || m_mode == Mode::DuplicateProject) {
        const bool copia = (m_mode == Mode::DuplicateProject);
        if (k == 27) {                       // ESC: cancelar
            m_draft.clear();
            m_mode = Mode::List;
            return Action::None;
        }
        if (k == '\b') {
            if (!m_draft.empty()) {
                m_draft.pop_back();
            }
            return Action::None;
        }
        if (k == '\n') {
            if (m_draft.empty()) {
                return Action::None;
            }
            if (copia) {
                const Project* origen = current();
                if (origen == nullptr) {
                    m_draft.clear();
                    m_mode = Mode::List;
                    return Action::None;
                }
                // duplicate() es todo-o-nada y no sobreescribe nada: si del
                // nombre saliera un id ocupado lo resuelve uniqueId, y si un
                // fichero de destino ya existiera falla sin haber escrito.
                auto d = ProjectIndex::duplicate(m_root, origen->id, m_draft);
                if (!d.isOk()) {
                    setMessage(false, "No se pudo duplicar '" + origen->id + "'",
                               d.errorMessage());
                    m_draft.clear();
                    return Action::None;
                }
                const ProjectIndex::DuplicateReport& informe = d.value();
                const std::string nuevoId = informe.project.id;
                const std::string nombre = informe.project.name;
                m_draft.clear();
                refresh();
                seleccionar(nuevoId);
                setMessage(true, "Proyecto '" + nombre + "' duplicado",
                           textoInforme(informe));
                return Action::None;
            }
            // El prefijo sale del id, no se pide aparte: pedirlo es una
            // pregunta mas en una pantalla donde ya hay que teclear, y la
            // respuesta correcta es casi siempre esta. Se puede cambiar
            // luego en el manifiesto.
            const std::string prefijo = m_draft.substr(0, 3) + "_";
            auto r = ProjectIndex::create(m_root, m_draft, m_draft, prefijo, "editor", "");
            if (!r.isOk()) {
                setMessage(false, "No se pudo crear '" + m_draft + "'", r.errorMessage());
                m_draft.clear();
                return Action::None;
            }
            const std::string creado = m_draft;
            m_draft.clear();
            refresh();
            // Dejarlo marcado: acabas de crearlo, es lo que quieres tocar.
            seleccionar(creado);
            setMessage(true, "Proyecto '" + creado + "' creado",
                       "Prefijo " + prefijo + ". Esta vacio: abrelo con ENTER,\n"
                       "dibuja un nivel y guardalo con F5.");
            return Action::None;
        }
        // Que se acepta mientras se teclea. NewProject escribe un ID y por
        // eso filtra a [a-z0-9_]: create() rechazaria lo demas y el autor no
        // se enteraria hasta pulsar ENTER. DuplicateProject escribe un
        // NOMBRE VISIBLE y suggestId lo pliega despues, asi que cabe lo que
        // el autor quiera decir, espacios y mayusculas incluidos. Los bytes
        // >= 0x80 se dejan pasar para que una entrada de texto UTF-8 llegue
        // entera: suggestId ya sabe plegar acentos y letras marcadas.
        const unsigned char u = static_cast<unsigned char>(k);
        const bool valido = copia
            ? (u >= 0x20 && u != 0x7F)
            : ((k >= 'a' && k <= 'z') || (k >= '0' && k <= '9') || k == '_');
        const std::size_t tope = copia ? 48 : 24;
        if (valido && m_draft.size() < tope) {
            m_draft += k;
        }
        return Action::None;
    }

    // --- Borrado pendiente de confirmar ---
    if (m_mode == Mode::ConfirmDelete) {
        // Solo ENTER borra; cualquier otra tecla (ESC incluida) cancela y
        // vuelve a la lista sin tocar nada.
        if (k != '\n') {
            m_mode = Mode::List;
            return Action::None;
        }
        const Project* p = current();
        if (p == nullptr) {
            m_mode = Mode::List;
            return Action::None;
        }
        const std::string id = p->id;
        const std::string nombre = p->name;
        auto r = ProjectIndex::remove(m_root, id);
        if (!r.isOk()) {
            setMessage(false, "No se pudo borrar '" + id + "'", r.errorMessage());
            return Action::None;
        }
        refresh();
        // Decir QUE no se borra importa tanto como decir que se borro:
        // remove() quita el manifiesto y lo saca del indice, pero deja los
        // niveles y los mapas en disco a proposito, porque pueden estar
        // referenciados por otro proyecto. Sin esta linea el autor cree
        // haber perdido el contenido.
        setMessage(true, "Proyecto '" + nombre + "' borrado",
                   "Fuera del indice y manifiesto borrado.\n"
                   "Sus niveles, mapas y catalogos SIGUEN EN DISCO: pueden\n"
                   "estar referenciados por otro proyecto. Lo que no reclame\n"
                   "nadie saldra como huerfano al revisar el indice.");
        return Action::None;
    }

    // --- Mostrando un mensaje: cualquier tecla vuelve ---
    if (m_mode == Mode::Message) {
        m_message.clear();
        m_mode = Mode::List;
        return Action::None;
    }

    // --- La lista ---
    switch (k) {
        case 'w':
            moveUp();
            return Action::None;
        case 's':
            moveDown();
            return Action::None;
        case 'n':
            m_draft.clear();
            m_mode = Mode::NewProject;
            return Action::None;
        case 'b':
            build();
            return Action::None;
        case 'd':
            // Sin proyecto marcado no hay nada que duplicar: no se abre el
            // campo de texto para acabar fallando al confirmar.
            if (current() == nullptr) {
                return Action::None;
            }
            m_draft.clear();
            m_mode = Mode::DuplicateProject;
            return Action::None;
        case 'x':
            if (current() == nullptr) {
                return Action::None;
            }
            m_mode = Mode::ConfirmDelete;
            return Action::None;
        case 27:
            return Action::Quit;
        case '\n': {
            const Project* p = current();
            if (p == nullptr) {
                return Action::None;
            }
            // Un proyecto sin niveles se abre igual, con una rejilla en
            // blanco: hay que poder empezar el primer nivel de algo. No se
            // avisa con un modal -- el panel de detalle ya dice "niveles
            // 0" antes de pulsar, y un aviso aqui saldria en bucle porque
            // al volver a la lista el proyecto sigue sin niveles.
            m_openId = p->id;
            return Action::Open;
        }
        default:
            return Action::None;
    }
}

}  // namespace Editor
