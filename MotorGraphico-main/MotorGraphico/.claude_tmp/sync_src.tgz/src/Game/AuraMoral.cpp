// PERGAMINO-01 — ver include/Game/AuraMoral.h.
#include "Game/AuraMoral.h"

#include <algorithm>
#include <cmath>

namespace Game {

namespace {
constexpr float kPi = 3.14159265358979f;

float fraccion(float v, float desde, float hasta) {
    return std::clamp((v - desde) / (hasta - desde), 0.0f, 1.0f);
}

// Numero pseudoaleatorio estable por particula (sin estado).
float semilla(int i, int canal) {
    const float s = std::sin(static_cast<float>(i * 127 + canal * 311) * 12.9898f) * 43758.5453f;
    return s - std::floor(s);
}
}  // namespace

TramoMoral tramoMoral(int valor) { return moral::tramoDe(valor); }

AspectoAura aspectoAura(int valorMoral) {
    const float v = static_cast<float>(std::clamp(valorMoral, -100, 100));
    AspectoAura a;
    a.tramo = tramoMoral(valorMoral);
    switch (a.tramo) {
        case TramoMoral::Neutral:
            return a;
        case TramoMoral::Respetado:  // halo tenue
            a.visible = true;
            a.luz = true;
            a.intensidad = 0.35f + 0.25f * fraccion(v, 20.0f, 59.0f);
            a.color = Vector4{1.0f, 0.80f, 0.38f, 1.0f};
            a.radio = 1.05f;
            break;
        case TramoMoral::Salvador:  // halo grande
            a.visible = true;
            a.luz = true;
            a.intensidad = 0.60f + 0.15f * fraccion(v, 60.0f, 74.0f);
            a.color = Vector4{1.0f, 0.83f, 0.40f, 1.0f};
            a.radio = 1.45f;
            break;
        case TramoMoral::Heroe:  // halo grande, alas celestiales, motas de luz
            a.visible = true;
            a.luz = true;
            a.intensidad = 0.70f + 0.30f * fraccion(v, 75.0f, 100.0f);
            a.color = Vector4{1.0f, 0.86f, 0.46f, 1.0f};
            a.radio = 1.55f;
            a.particulas = 6;
            a.motas = true;
            a.alas = Alas::Celestiales;
            a.colorAlas = Vector4{1.0f, 0.95f, 0.80f, 0.40f + 0.30f * a.intensidad};
            break;
        case TramoMoral::Canalla:  // humo rojo oscuro a los pies
            a.visible = true;
            a.intensidad = 0.40f + 0.25f * fraccion(-v, 20.0f, 59.0f);
            a.color = Vector4{0.33f, 0.05f, 0.04f, 1.0f};
            a.radio = 1.0f;
            a.particulas = 4;
            a.tinteSprite = Vector4{0.93f, 0.86f, 0.86f, 1.0f};
            break;
        case TramoMoral::Desgraciado:  // humo espeso y el sprite en sombra
            a.visible = true;
            a.intensidad = 0.70f + 0.20f * fraccion(-v, 60.0f, 74.0f);
            a.color = Vector4{0.24f, 0.02f, 0.02f, 1.0f};
            a.radio = 1.25f;
            a.particulas = 7;
            // En sombra y con el rojo del humo: se ve de lejos.
            a.tinteSprite = Vector4{0.80f, 0.66f, 0.66f, 1.0f};
            break;
        case TramoMoral::Villano:  // halo grande, alas demoníacas, motas de sombra
            a.visible = true;
            a.intensidad = 0.80f + 0.20f * fraccion(-v, 75.0f, 100.0f);
            a.color = Vector4{0.14f, 0.01f, 0.02f, 1.0f};
            a.radio = 1.55f;
            a.particulas = 7;
            a.motas = true;
            a.alas = Alas::Demoniacas;
            a.colorAlas = Vector4{0.13f, 0.01f, 0.03f, 0.85f};
            a.tinteSprite = Vector4{0.76f, 0.62f, 0.62f, 1.0f};
            break;
    }
    return a;
}

float pulsoAura(float segundos) { return 0.925f + 0.075f * std::sin(segundos * 2.0f * kPi / 2.4f); }

ParticulaAura particulaAura(const AspectoAura& aspecto, int indice, float segundos) {
    ParticulaAura p;
    if (!aspecto.visible || indice < 0 || indice >= aspecto.particulas) return p;
    if (aspecto.luz || aspecto.motas) {
        // Motas (de luz o de sombra): nacen en el halo, suben y se apagan;
        // cada una con su periodo y su fase para que no suban en fila.
        const float periodo = 1.6f + 0.9f * semilla(indice, 1);
        const float t = std::fmod(segundos / periodo + semilla(indice, 2), 1.0f);
        p.dx = (semilla(indice, 3) - 0.5f) * 0.7f * std::min(aspecto.radio, 1.3f);
        p.dy = -0.05f - t * 1.1f;
        p.radio = 0.05f + 0.03f * semilla(indice, 4);
        p.alfa = aspecto.intensidad * std::sin(t * kPi);
        return p;
    }
    // Volutas de humo: giran despacio alrededor de los pies y se levantan
    // un poco antes de deshacerse.
    const float periodo = 2.8f + 1.4f * semilla(indice, 1);
    const float t = std::fmod(segundos / periodo + semilla(indice, 2), 1.0f);
    const float giro = semilla(indice, 3) * 2.0f * kPi + segundos * 0.6f;
    p.dx = std::cos(giro) * 0.32f * aspecto.radio;
    p.dy = std::sin(giro) * 0.12f * aspecto.radio - t * 0.35f;
    p.radio = (0.22f + 0.18f * t) * aspecto.radio;
    p.alfa = aspecto.intensidad * 0.55f * std::sin(t * kPi);
    return p;
}

PlumaAla plumaAla(const AspectoAura& aspecto, int lado, int indice, float segundos) {
    PlumaAla p;
    if (aspecto.alas == Alas::Ninguna || indice < 0 || indice >= kPlumasPorAla || lado == 0) return p;
    const float s = lado < 0 ? -1.0f : 1.0f;
    const bool demonio = aspecto.alas == Alas::Demoniacas;
    // En abanico desde el hombro: la primera, hacia arriba y afuera; la
    // ultima, hacia abajo. Las del demonio, mas afiladas y mas abiertas.
    const float abre = demonio ? 34.0f : 30.0f;
    const float bate = 6.0f * std::sin(segundos * 2.0f * kPi / 2.6f);
    const float grados = -72.0f + abre * static_cast<float>(indice) + bate;
    const float a = grados * kPi / 180.0f;
    static const float kLargo[kPlumasPorAla] = {0.62f, 0.70f, 0.64f, 0.52f, 0.40f};
    const float largo = kLargo[indice] * (demonio ? 1.05f : 1.0f);
    const float anchoBase = demonio ? 0.050f : 0.075f, anchoPunta = demonio ? 0.012f : 0.045f;
    // El ala derecha; la izquierda es su espejo (sin culling, el giro da igual).
    const float dx = std::cos(a), dy = std::sin(a);
    const float nx = -dy, ny = dx;  // perpendicular
    const float bx = 0.10f, by = 0.02f;
    const float tx = bx + dx * largo, ty = by + dy * largo;
    // arriba-izquierda, arriba-derecha, abajo-derecha, abajo-izquierda
    p.x[0] = bx + nx * anchoBase;  p.y[0] = by + ny * anchoBase;
    p.x[1] = tx + nx * anchoPunta; p.y[1] = ty + ny * anchoPunta;
    p.x[2] = tx - nx * anchoPunta; p.y[2] = ty - ny * anchoPunta;
    p.x[3] = bx - nx * anchoBase;  p.y[3] = by - ny * anchoBase;
    for (float& x : p.x) x *= s;
    p.alfa = aspecto.colorAlas.w * (0.85f + 0.15f * std::cos(static_cast<float>(indice)));
    return p;
}

}  // namespace Game
