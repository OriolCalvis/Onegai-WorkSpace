// >>> PAQUETES DEL PLAN - bloque generado, no editar a mano >>>
// Este fichero lo tocan 14 paquetes del corte B:
//   C-02  (fase C, 1 j) - El minimapa deixa de llegir memòria alliberada
//   C-03  (fase C, 2 j) - L'estat del jugador sobreviu el canvi de nivell
//   C-05  (fase C, 1 j) - Tancament ordenat dels recursos GL
//   C-07  (fase C, 2 j) - Les aventures autònomes disparen els seus beats
//   C-16  (fase C, 4 j) - L'Application delega en SceneManager
//   C-17  (fase C, 6 j) - World és el propietari de les entitats
//   C-23  (fase C, 4 j) - El post-processat arriba al joc
//   F-01  (fase F, 4 j) - Playtest des de l'editor
//   F-03  (fase F, 4 j) - Recàrrega en calent
//   G-08  (fase G, 4 j) - Títol i arrencada del projecte
//   G-09  (fase G, 3 j) - Creació de personatge dins de Nova partida
//   G-10  (fase G, 3 j) - Menú de partida, opcions i focus
//   G-13  (fase G, 5 j) - Comandes de combat i objectius des de dades
//   G-14  (fase G, 3 j) - HUD, diàlegs i comerç amb accions visibles
//
// AVISO - FICHERO DE CRUCE. Con 14 paquetes encima, es de los
// sitios donde dos agentes se pisan sin enterarse. Antes de una
// refactorizacion grande aqui, mira si hay trabajo sin commitear
// (git status) y di en que paquete estas trabajando.
//
// Si tocas este fichero estas trabajando dentro de esos paquetes: su
// criterio de cierre y su prueba mandan sobre lo que es 'estar hecho'.
// Criterios y pruebas: planificacion/PLA_DEFINITIU.md
// Mapa completo fichero <-> paquete: planificacion/MAPA_DEL_CODIGO.md
// Regenerar este bloque: python3 tools/marcar_paquetes.py --marcar
// <<< fin del bloque generado <<<

#include "Engine/Application.h"
#include "Engine/ApplicationInternal.h"

#include "Core/Math/IsoMath.h"
#include "Core/Resources/Shader.h"
#include "Core/Resources/Texture.h"
#include "Engine/Input/InputSystem.h"
#include "Engine/ApplicationLoop.h"
#include "Engine/Window.h"
#include "Render/AnimatedEntity.h"
#include "Render/BlobShadow.h"
#include "Render/Camera.h"
#include "Render/DynamicLightMap.h"
#include "Render/FogOfWar.h"
#include "Render/HojaPersonaje.h"
#include "Engine/InputState.h"
#include "Game/BattleMenuActions.h"
#include "Game/OptionsLocaleBridge.h"
#include "Game/SaveGame.h"
#include "Game/SaveSlotState.h"
#include "Level/LevelLoader.h"
#include "Render/Player.h"
#include "Render/AuraJugador.h"
#include "Render/BancoAtlas.h"
#include "Render/BloquesNivel.h"
#include "Render/BandadaNivel.h"
#include "Render/MonumentosNivel.h"
#include "Render/PergaminoGL.h"
#include "Game/PlayerControls.h"
#include "Render/StaticEntity.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <filesystem>
#include <iostream>
#include <map>
#include <unordered_map>
#include <vector>

// glad ANTES que GLFW (mismo orden y motivo que src/Engine/Window.cpp).
#include <glad/glad.h>

#include <GLFW/glfw3.h>

// EST-20 — los ayudantes compartidos del fichero (los tres colores del
// HUD, el tamano del tile y la traza) viven en ApplicationInternal.h
// desde que el flujo se partio en tres unidades. El using deja los
// cuerpos que quedan aqui exactamente como estaban.
using namespace Engine::Interno;

// Colors compartits de tots els panells del HUD. Visibles a tot el
// translation unit (fora de qualsevol namespace) perquè tant les funcions
// dins l'anonymous namespace com els mètodes d'Application els fan servir.

namespace {


// --- Sprite de personaje (el cuerpo base, assets/textures/personaje.png) ---
// Hoja de 12 frames de 64x64: arriba 1-3, derecha 4-6, abajo 7-9, izquierda
// 10-12 (paso, quieto, paso). Los ciclos los reparte HojaPersonaje::animar(),
// igual que en la hoja del personaje creado (APARIENCIA-01). Antes se leia
// como 1-4 abajo y 5-8 arriba: el jugador se paraba de espaldas (ARTE-01).
constexpr int kCharacterFrameW = 64;               // ancho de UN frame en la hoja
constexpr int kCharacterFrameH = 64;               // alto de UN frame en la hoja
constexpr int kCharacterFrameCount = 12;            // 768 / 64

// El sprite de personaje es cuadrado (64x64) pero el tile isometrico es un
// rombo 2:1 (64x32). Para que el actor "pise" la celda, se dibuja a este
// tamano y se ancla asi:
//   - horizontal: centrado sobre el centro del rombo del tile
//   - vertical:   la BASE del sprite sobre la base del rombo
// drawH un poco mayor que tileH (64 vs 32) da altura al personaje sobre el
// suelo, lo tipico de un "billboard" en iso. Se dibuja MAS GRANDE que el
// tile a proposito: el actor ocupa su celda y asoma por arriba, como en
// cualquier RPG isometrico.


// Textura 1x1 blanca para los widgets de HUD que dibujan color solido
// (mismo patron que demo_hud.cpp/level_editor.cpp).
Texture* makeWhiteTexture() {
    unsigned char whitePixel[4] = {255, 255, 255, 255};
    unsigned int glID = 0;
    glGenTextures(1, &glID);
    glBindTexture(GL_TEXTURE_2D, glID);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, 1, 1, 0, GL_RGBA, GL_UNSIGNED_BYTE, whitePixel);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glBindTexture(GL_TEXTURE_2D, 0);
    return new Texture(glID, 1, 1);
}

// Único adaptador GLFW -> Engine::Input. El sistema de entrada no conoce
// códigos de GLFW, y Application no conserva flancos por su cuenta (ADR-008).
Engine::Input::RawInputState readGameKeyboard(GLFWwindow* window) {
    using Engine::Input::InputKey;
    const std::pair<InputKey, int> bindings[] = {
        {InputKey::Escape, GLFW_KEY_ESCAPE}, {InputKey::W, GLFW_KEY_W},
        {InputKey::A, GLFW_KEY_A},           {InputKey::S, GLFW_KEY_S},
        {InputKey::D, GLFW_KEY_D},           {InputKey::E, GLFW_KEY_E},
        {InputKey::Tab, GLFW_KEY_TAB},       {InputKey::F5, GLFW_KEY_F5},
        {InputKey::F9, GLFW_KEY_F9},         {InputKey::Enter, GLFW_KEY_ENTER},
        {InputKey::Space, GLFW_KEY_SPACE},   {InputKey::LeftArrow, GLFW_KEY_LEFT},
        {InputKey::RightArrow, GLFW_KEY_RIGHT},
    };

    Engine::Input::RawInputState state;
    for (const auto& [key, glfwKey] : bindings) {
        state.setDown(key, glfwGetKey(window, glfwKey) == GLFW_PRESS);
    }
    return state;
}

// PERGAMINO-01 — «Centro de Boundington · 17:42» (P05a): donde y a que
// hora se ha guardado, bajo el «Partida guardada» del papiro de pausa.
std::string detalleGuardado(const std::string& zona) {
    const std::time_t ahora = std::time(nullptr);
    char hora[8] = "";
    if (const std::tm* local = std::localtime(&ahora)) std::strftime(hora, sizeof hora, "%H:%M", local);
    return zona.empty() ? std::string(hora) : zona + " · " + hora;
}

// El motivo de un guardado o carga fallidos: la ultima nota del registro
// sin su prefijo («No se puede guardar: <motivo>»).
std::string motivoDeLaNota(const GameSession& sesion) {
    if (sesion.log().empty()) return {};
    const std::string& nota = sesion.log().back();
    const auto dos = nota.find(": ");
    return dos == std::string::npos ? nota : nota.substr(dos + 2);
}

}  // namespace

Application::Application() : m_playerSkills(/*maxMana=*/8) {}

Application::~Application() { shutdown(); }

Result<bool> Application::init(int width, int height, const std::string& title,
                               const std::string& levelPath, const std::string& catalogPath,
                               const std::string& initialAdventurePath,
                               const std::vector<std::string>& extraCatalogPaths,
                               bool startAtTitle) {
    m_width = width;
    m_height = height;

    try {
        m_window = std::make_unique<Window>(width, height, title);
    } catch (const std::exception& e) {
        // Window lanza EngineException (fallo de arranque); aqui se
        // convierte a Result para que el llamador (main) decida, en vez
        // de propagar una excepcion desde init().
        return Result<bool>::Error(std::string("No se pudo crear la ventana: ") + e.what());
    }

    trace("init: ventana + contexto GL OK");
    // SpriteBatch DESPUES de la Window: su constructor llama a
    // glGenVertexArrays y necesita el contexto GL + GLAD ya cargados
    // (ver el comentario de m_hudBatch en Application.h).
    m_hudBatch = std::make_unique<SpriteBatch>();
    trace("init: SpriteBatch del HUD OK");
    auto shaderResult = m_shaderManager.load("sprite", "assets/shaders/sprite");
    if (!shaderResult.isOk()) {
        return Result<bool>::Error("Shader sprite: " + shaderResult.errorMessage());
    }
    m_spriteShader = shaderResult.value();

    trace("init: shader sprite OK");
    // C-23 — Shaders de post-processat. Es carreguen sempre (son barats)
    // pero solo s'usen si el nivell ho demana.
    auto fogShaderResult = m_shaderManager.load("fog", "assets/shaders/fog");
    if (fogShaderResult.isOk()) {
        m_fogShader = fogShaderResult.value();
    }
    auto lightmapShaderResult = m_shaderManager.load("lightmap", "assets/shaders/lightmap");
    if (lightmapShaderResult.isOk()) {
        m_lightmapShader = lightmapShaderResult.value();
    }
    // H0-01 — la campaña se resuelve ANTES de cargar el nivel: con
    // startAtTitle se escanea el índice para saber qué proyecto se juega,
    // porque sus catálogos tienen que entrar en m_objectCatalog a tiempo de
    // que las referencias de los mapas (391 inertes en Boundington) resuelvan.
    // El bloque del título de más abajo ya no vuelve a escanear.
    if (startAtTitle) {
        auto indexResult = Editor::ProjectIndex::scan("assets");
        if (indexResult.isOk() && !indexResult.value().projects().empty()) {
            m_projectIndex = indexResult.value();
        }
    }
    // --- Contenido dirigido por datos (Fases 6 y 10) ---
    auto catalogResult = m_objectCatalog.loadFromFile(catalogPath);
    if (!catalogResult.isOk()) {
        return Result<bool>::Error("Catalogo de objetos: " + catalogResult.errorMessage());
    }
    for (const std::string& extraPath : extraCatalogPaths) {
        auto extraResult = m_objectCatalog.loadFromFile(extraPath);
        if (!extraResult.isOk()) {
            return Result<bool>::Error("Catalogo adicional " + extraPath + ": " +
                                       extraResult.errorMessage());
        }
    }
    // H0-01 — la campaña pasa por el manifiesto, no por el catálogo suelto
    // (juego.cpp carga boundington_npcs.json a secas). Mismo recorrido que
    // openProject: por cada fichero de project.catalogs se hace loadFromFile
    // contra catalogsDirectory. Estricto como en openProject: un catálogo
    // declarado que no carga es un manifiesto roto, no se juega a medias.
    if (startAtTitle && !m_projectIndex.projects().empty()) {
        const auto& campaign = m_projectIndex.projects().front();
        for (const auto& file : campaign.catalogs) {
            const auto path =
                "assets/" + campaign.settings.catalogsDirectory + "/" + file;
            const auto loaded = m_objectCatalog.loadFromFile(path);
            if (!loaded.isOk()) {
                return Result<bool>::Error("Catalogo de campana " + path + ": " +
                                           loaded.errorMessage());
            }
        }
        trace("init: catalogos de la campana desde el manifiesto OK");
    }

    // Habilidades disponibles. A mano y no desde JSON: no hay todavia un
    // archivo de habilidades (el Gantt lo deja fuera de la Fase 7, que
    // solo pedia SkillCatalog); en cuanto exista, esto pasa a ser otro
    // loadFromFile como el catalogo de objetos.
    m_skillCatalog.add(Skill{"tajo", "Tajo", 3, 12, SkillEffect::Damage,
                             SkillTarget::SingleEnemy});
    m_skillCatalog.add(Skill{"cura", "Cura", 4, 20, SkillEffect::Heal, SkillTarget::Self});
    // Habilidad del slime (defecto 04 del documento de diseno del
    // editor): test_objects.json le da combat.skills =
    // ["golpe_gelatinoso"], pero nadie la registraba en el catalogo --
    // SkillCatalog::find() devolvia nullptr y el slime caia EN SILENCIO
    // al ataque basico. Registrada aqui junto a las del jugador hasta
    // que las habilidades se carguen desde JSON (ver el comentario de
    // arriba).
    m_skillCatalog.add(Skill{"golpe_gelatinoso", "Golpe gelatinoso", 2, 8, SkillEffect::Damage,
                             SkillTarget::SingleEnemy});
    m_playerSkills.learn("tajo");
    m_playerSkills.learn("cura");

    trace("init: catalogos + skills OK");
    // --- Atlas de PERSONAJES (jugador, NPCs, enemigos). Hoja independiente
    // del tileset del mapa: los actores no son tiles. Se carga una sola vez
    // en init() y sobrevive a los cambios de nivel igual que el Player (el
    // tileset m_atlas se reconstruye en cada loadLevel; este no). ---
    auto charTexResult = m_textureManager.load("personaje", "assets/textures/personaje.png");
    if (!charTexResult.isOk()) {
        return Result<bool>::Error("Textura de personaje: " + charTexResult.errorMessage());
    }
    m_characterAtlas = std::make_unique<TextureAtlas>(charTexResult.value(), kCharacterFrameW,
                                                       kCharacterFrameH);
    // 12 frames en una fila: id i -> columna (i-1). El id 0 se deja sin
    // definir a proposito (AnimatedEntity arranca con spriteID 0 hasta el
    // primer play(); que getUV(0) devuelva UVRect{} --textura entera-- solo
    // se ve en el frame cero, antes del primer play, que nunca llega a
    // pantalla porque init() llama a refreshHud/NO al play; pero
    // processInput si: la primera tecla de movimiento dispara play() y fija
    // un frame valido. idle usa el frame 1, asi que en cuanto el jugador
    // pulsa una vez, ya hay sprite correcto; y en el frame de arranque el
    // play("idle") de abajo lo deja fino.)
    for (int i = 1; i <= kCharacterFrameCount; ++i) {
        m_characterAtlas->defineRegion(i, /*col=*/i - 1, /*row=*/0);
    }

    // SPRITES-01 — el resto de hojas (historia, razas, props, pickups y lo
    // que llegue de PixelLab) las describe assets/textures/sprites.json.
    // Sin indice o con avisos el juego sigue: cae en el cuerpo base y en
    // los tiles tenidos de siempre.
    m_bancoAtlas = std::make_unique<Render::BancoAtlas>(m_textureManager, "assets");
    if (const auto r = m_bancoAtlas->carga(); !r.isOk()) {
        std::cerr << "SPRITES-01: " << r.errorMessage() << "\n";
    }
    for (const std::string& aviso : m_bancoAtlas->registro().avisos()) {
        std::cerr << "SPRITES-01: " << aviso << "\n";
    }
    // BLOQUES-01 — sin bloques.json los edificios siguen planos.
    m_bloques = std::make_unique<Render::BloquesNivel>();
    if (const auto r = m_bloques->carga("assets"); !r.isOk()) {
        std::cerr << "BLOQUES-01: " << r.errorMessage() << "\n";
    }
    m_bandada = std::make_unique<Render::BandadaNivel>();
    m_monumentos = std::make_unique<Render::MonumentosNivel>();
    if (const auto r = m_monumentos->carga("assets"); !r.isOk()) {
        std::cerr << "BLOQUES-03: " << r.errorMessage() << "\n";
    }
    trace("init: atlas de personaje OK");

    // --- Jugador (Entity real, se ve en pantalla). Su posicion la fija
    // loadLevel() mas abajo, con el playerStart del nivel. ---
    m_player = std::make_unique<Player>(GridCoord{0, 0}, m_atlas.get(), kTileW, kTileH);
    // Sprite de personaje: el bebé de personaje.png, no el tileset.
    m_player->setCharacterSprite(m_characterAtlas.get(), kCharacterDrawW, kCharacterDrawH,
                                 characterAnchor());
    // Los ciclos de andar del reparto real de la hoja (ver arriba). Al crear
    // personaje, PantallaNuevaPartida::vestir() le pone su propia hoja.
    HojaPersonaje::animar(*m_player);
    m_player->play("idle");  // frame valido desde el primer render()

    trace("init: player OK");

    // --- Stats del jugador para tiradas Nd6 ---
    // Sin esto m_player->stat() devuelve 0 en los cuatro atributos
    // (Player.h los inicializa a {0,0,0,0}) y cada skillCheck tiraria 1
    // solo dado: los cuatro grados (BOTCH/PARTIAL/SUCCESS/CRITICAL)
    // colapsarian. Le damos un reparto de aventurero novato (0..8, GDD).
    // Percepcion es DES -> 3 dados; Conocimiento Arcano es INT -> 2 dados.
    m_player->set_stat(RPG::Stat::CON, 3);
    m_player->set_stat(RPG::Stat::DES, 3);
    m_player->set_stat(RPG::Stat::INT, 2);
    m_player->set_stat(RPG::Stat::CAR, 2);

    // --- Campana narrativa de Boundington (prologo + Dia 1) ---
    // Se carga aqui y no en loadLevel porque las aventuras son contenido
    // de toda la partida: sobreviven a las transiciones de nivel. Si una
    // falla al cargar (fichero perdido, JSON roto), no es fatal para el
    // motor grafico: arrancamos sin narrativa y el juego funciona como
    // antes (ciudad + combate). Por eso m_narrativaLista.
    auto prologoR = RPG::AdventureScript::loadFromFile("assets/adventures/boundington_prologo.json");
    auto dia1R = RPG::AdventureScript::loadFromFile("assets/adventures/boundington_primer_dia.json");
    auto dia2R = RPG::AdventureScript::loadFromFile("assets/adventures/boundington_segundo_dia.json");
    auto ocasoR = RPG::AdventureScript::loadFromFile("assets/adventures/boundington_ocaso.json");
    auto nd6R = m_nd6Skills.loadFromFile("assets/catalogs/skills.json");
    if (prologoR.isOk() && dia1R.isOk() && dia2R.isOk() && ocasoR.isOk() && nd6R.isOk()) {
        m_prologo = prologoR.value();
        m_dia1 = dia1R.value();
        m_dia2 = dia2R.value();
        m_ocaso = ocasoR.value();
        m_narrative.setAdventure(&m_prologo);  // arrancamos por el prologo
        m_narrativaLista = true;
        m_narrativeCampaignTransitions = true;
        if (!initialAdventurePath.empty()) {
            auto customAdventure = RPG::AdventureScript::loadFromFile(initialAdventurePath);
            if (!customAdventure.isOk()) {
                return Result<bool>::Error("Aventura inicial: " + customAdventure.errorMessage());
            }
            m_prologo = customAdventure.value();
            m_narrative.setAdventure(&m_prologo);
            m_narrativeCampaignTransitions = false;
            trace("init: aventura inicial alternativa cargada");
        }
        trace("init: campana de Boundington cargada (prologo + 3 dias)");
    } else {
        // No abortamos: el motor grafico sigue siendo usable sin narrativa.
        // trace() toma const char*; para mensajes con contenido variable
        // (el errorMessage) tiramos de stderr directo.
        if (!prologoR.isOk()) std::fprintf(stderr, "init: prologo NO cargo: %s\n",
                                           prologoR.errorMessage().c_str());
        if (!dia1R.isOk())    std::fprintf(stderr, "init: Dia 1 NO cargo: %s\n",
                                           dia1R.errorMessage().c_str());
        if (!dia2R.isOk())    std::fprintf(stderr, "init: Dia 2 NO cargo: %s\n",
                                           dia2R.errorMessage().c_str());
        if (!ocasoR.isOk())   std::fprintf(stderr, "init: Ocaso NO cargo: %s\n",
                                           ocasoR.errorMessage().c_str());
        if (!nd6R.isOk())     std::fprintf(stderr, "init: catalogo Nd6 NO cargo: %s\n",
                                           nd6R.errorMessage().c_str());
        m_narrativaLista = false;
    }

    m_camera = std::make_unique<Camera>(width, height);
    m_renderer = std::make_unique<IsometricRenderer>(m_camera.get(), &m_map, m_atlas.get(),
                                                     m_spriteShader);
    m_renderer->addToQueue(m_player.get());
    // PERGAMINO-01 — la moral en el avatar: el aura va en la misma cola.
    m_aura = std::make_unique<AuraJugador>(m_player.get(), 64, 32);
    m_renderer->addToQueue(m_aura.get());

    trace("init: camara + renderer OK");
    // Sombras blob (Fase 11).
    m_shadowTexture.reset(CreateBlobShadowTexture(64));
    m_renderer->setBlobShadows(m_shadowTexture.get());
    m_renderer->setBlobShadowsEnabled(true);

    trace("init: sombras blob OK");
    // Nivel inicial: mapa, tileset, sesion y marcadores (ver loadLevel).
    const auto conditionsLoaded = m_conditions.loadFromFile("assets/catalogs/conditions.json");
    if (!conditionsLoaded.isOk()) {
        return Result<bool>::Error("Condiciones: " + conditionsLoaded.errorMessage());
    }
    // D-08 — MonsterCatalog para que GameSession cree enemigos con stats
    // reales en vez de solo ObjectCatalog.maxHealth.
    const auto monstersLoaded = m_monsterCatalog.loadFromFile("assets/catalogs/monsters.json");
    if (!monstersLoaded.isOk()) {
        return Result<bool>::Error("Monstruos: " + monstersLoaded.errorMessage());
    }
    // H0-04 — G-12: el catalogo de equipo viaja a la sesion via
    // setInventoryRules (lo inyecta loadLevel). Sin el, equipar respondería
    // "no hay catalogo de equipo cargado" y las piezas quedarian inertes.
    // Carga estructural: es contenido, lo no declarado no es error del motor.
    const auto equipmentLoaded =
        m_equipmentCatalog.loadFromFile("assets/catalogs/equipment.json");
    if (!equipmentLoaded.isOk()) {
        return Result<bool>::Error("Equipo: " + equipmentLoaded.errorMessage());
    }
    // PERGAMINO-01 — antes del primer nivel: loadLevel le dice la zona. El
    // rombo de la E va en el suelo, en la cola del renderer.
    m_pergamino = std::make_unique<Render::PergaminoGL>();
    m_renderer->addToQueue(m_pergamino->marcaSuelo());
    auto levelLoaded = loadLevel(levelPath, /*useEntry=*/false, GridCoord{0, 0});
    if (!levelLoaded.isOk()) {
        return levelLoaded;
    }
    // Bolsa inicial: sin ella la primera tienda no se puede usar y el
    // sistema de comercio parece roto en la primera partida. Va aqui y
    // no en GameSession porque es una decision de CONTENIDO (cuanto
    // empieza teniendo el heroe), no una regla del motor.
    m_session->addGold(150);
    trace("init: nivel inicial OK");
    // H0-05 — servicio de ranuras: raiz "saves", proyecto actual. Sin
    // proyecto (arranque directo con --nivel) las ranuras caen en la raiz.
    setupSaveSlots();

    // H1-05 — cargar las tablas de idioma si existen (assets/i18n).
    // Best-effort: si falta el directorio, m_locale se queda sin cargar y
    // la fila IDIOMA del submenu de Opciones sigue siendo navegable pero
    // aplica el estado de arranque (sin traducir).
    if (std::filesystem::exists("assets/i18n")) {
        m_locale = std::make_unique<Engine::Locale>();
        if (m_locale->loadFromDirectory("assets/i18n").isOk()) {
            trace("init: tablas de idioma cargadas");
        } else {
            m_locale.reset();
        }
    }

    // --- HUD (Fase 9, rediseño) ---
    m_whiteTexture.reset(makeWhiteTexture());
    m_font = std::make_unique<BitmapFont>(/*scale=*/2);

    trace("init: whiteTexture + BitmapFont OK");

    // PERGAMINO-01 — el panel del jugador, sus barras (PV, PM y moral), el
    // minimapa y el inventario de texto los sustituye el tema pergamino
    // (Render/PergaminoGL): se crea con los iconos en createIconWidgets().

    // Panel del enemigo (arriba-centro): solo visible en combate,
    // refreshHud() le pone nombre y vida del enemigo del BattleState.
    HudTransform enemyPanelTransform;
    enemyPanelTransform.anchor = HudAnchor::TopCenter;
    enemyPanelTransform.offset = {0.0f, 12.0f};
    enemyPanelTransform.size = {280.0f, 68.0f};
    m_enemyPanel = std::make_unique<HudPanel>(enemyPanelTransform, m_whiteTexture.get(),
                                              kPanelColor);
    m_enemyPanel->setBorder(kBorderColor, 2.0f);

    HudTransform enemyTextTransform;
    enemyTextTransform.anchor = HudAnchor::TopCenter;
    enemyTextTransform.offset = {0.0f, 24.0f};
    enemyTextTransform.size = {232.0f, 14.0f};
    m_enemyText = std::make_unique<HudText>(enemyTextTransform, m_font.get());

    HudTransform enemyBarTransform;
    enemyBarTransform.anchor = HudAnchor::TopCenter;
    enemyBarTransform.offset = {0.0f, 48.0f};
    enemyBarTransform.size = {232.0f, 14.0f};
    m_enemyBar = std::make_unique<HudBar>(enemyBarTransform, m_whiteTexture.get());
    m_enemyBar->setBorder(kBorderColor, 1.0f);
    m_enemyBar->setThresholdColors(Vector4{0.25f, 0.75f, 0.3f, 1.0f},
                                   Vector4{0.9f, 0.75f, 0.2f, 1.0f},
                                   Vector4{0.85f, 0.2f, 0.15f, 1.0f});
    m_enemyBar->setAnimationSpeed(6.0f);

    // Arriba-derecha: FPS reales + minimapa.
    HudTransform fpsTransform;
    fpsTransform.anchor = HudAnchor::TopRight;
    fpsTransform.offset = {12.0f, 12.0f};
    fpsTransform.size = {90.0f, 14.0f};
    m_fpsText = std::make_unique<HudText>(fpsTransform, m_font.get());
    m_fpsText->setColor(Vector4{0.7f, 0.7f, 0.75f, 1.0f});

    // Linea de controles del modo actual (abajo-derecha, fuera del panel
    // del jugador -- ver refreshHud, defecto 01).
    // Caja de 280px: con el dialogo de 648 centrado a 1280 de ancho, su
    // borde derecho queda en x=964 y esta caja empieza en x=984 -- sin
    // rozarse (verificado con la vista previa pixel a pixel del HUD).
    // Las tres lineas de refreshHud() caben en 28 caracteres a escala 2.
    HudTransform hintTransform;
    hintTransform.anchor = HudAnchor::BottomRight;
    hintTransform.offset = {16.0f, 10.0f};
    hintTransform.size = {280.0f, 14.0f};
    m_hintText = std::make_unique<HudText>(hintTransform, m_font.get());
    m_hintText->setColor(Vector4{0.7f, 0.7f, 0.75f, 1.0f});

    // Cuadro de dialogo con marco: un HudPanel 4px mayor por cada lado
    // dibujado debajo hace de borde (el fondo lo pinta el propio
    // HudDialogueBox). 640 de ancho, no mas: deja libre la esquina
    // inferior-derecha para m_hintText a 1280 de ancho de ventana.
    //
    // maxLines=6 (antes 4): los beats narrativos del prologo llegan a 5
    // lineas y con 4 se truncaba la primera. Panel/altura crecidos para
    // acomodar las dos lineas extra (~16px/linea de fuente).
    HudTransform dialogueFrameTransform;
    dialogueFrameTransform.anchor = HudAnchor::BottomCenter;
    dialogueFrameTransform.offset = {0.0f, 12.0f};
    dialogueFrameTransform.size = {648.0f, 140.0f};
    m_dialoguePanel = std::make_unique<HudPanel>(dialogueFrameTransform, m_whiteTexture.get(),
                                                 kBorderColor);

    HudTransform dialogueTransform;
    dialogueTransform.anchor = HudAnchor::BottomCenter;
    dialogueTransform.offset = {0.0f, 16.0f};
    dialogueTransform.size = {640.0f, 132.0f};
    m_dialogue = std::make_unique<HudDialogueBox>(dialogueTransform, m_font.get(),
                                                 m_whiteTexture.get(), /*maxLines=*/6);

    // Menu de comandos con su panel MEDIDO CONTRA EL CONTENIDO (defecto
    // 06 del documento de diseno: el panel fijo de 248x118 cuadruplicaba
    // sus ~80x70 de texto). La medida la da el propio widget
    // (HudCommandMenu::contentSize, que ya cuenta el prefijo del cursor
    // y el interlineado real de la fuente), no una cuenta duplicada
    // aqui que se pudiera desincronizar; el panel solo anade
    // kMenuPadding por cada lado. Si manana cambian las opciones o la
    // escala de la fuente, el panel se ajusta solo.
    // Contenido inicial placeholder (los comandos de base): al entrar en
    // combate, refreshHud() las reemplaza por los comandos de base mas
    // las habilidades de la ficha (H1-01, G-13) sin ids escritos a mano.
    const std::vector<std::string> commandOptions{"Atacar", "Pocion", "Huir"};
    const Vector2 menuSize = HudCommandMenu::contentSize(*m_font, commandOptions);

    HudTransform menuTransform;
    menuTransform.anchor = HudAnchor::BottomLeft;
    menuTransform.offset = {24.0f, 140.0f};
    menuTransform.size = menuSize;
    m_commandMenu =
        std::make_unique<HudCommandMenu>(menuTransform, m_font.get(), commandOptions);

    HudTransform menuPanelTransform;
    menuPanelTransform.anchor = HudAnchor::BottomLeft;
    menuPanelTransform.offset = {24.0f - kMenuPadding, 140.0f - kMenuPadding};
    menuPanelTransform.size = {menuSize.x + 2.0f * kMenuPadding,
                               menuSize.y + 2.0f * kMenuPadding};
    m_commandPanel = std::make_unique<HudPanel>(menuPanelTransform, m_whiteTexture.get(),
                                                kPanelColor);
    m_commandPanel->setBorder(kBorderColor, 2.0f);

    // --- Tienda: mismo anclaje que el menu de combate (nunca coinciden
    // en pantalla, son modos excluyentes) pero mas ancha, porque cada
    // linea lleva nombre + precio. ---
    HudTransform shopPanelTransform;
    shopPanelTransform.anchor = HudAnchor::Center;  // TIENDA-01: centrada sobre el dialogo
    shopPanelTransform.offset = {0.0f, -60.0f};
    shopPanelTransform.size = {560.0f, 340.0f};
    m_shopPanel = std::make_unique<HudPanel>(shopPanelTransform, m_whiteTexture.get(),
                                             kPanelColor);
    m_shopPanel->setBorder(kBorderColor, 2.0f);

    HudTransform shopTitleTransform;
    shopTitleTransform.anchor = HudAnchor::Center;
    shopTitleTransform.offset = {-220.0f, -210.0f};  // esquina del panel (560x340 en -60) + padding
    m_shopTitle = std::make_unique<HudText>(shopTitleTransform, m_font.get());
    m_shopTitle->setColor(Vector4{1.0f, 0.9f, 0.5f, 1.0f});

    HudTransform shopMenuTransform;
    shopMenuTransform.anchor = HudAnchor::Center;
    shopMenuTransform.offset = {0.0f, -52.0f};  // bajo el titulo
    shopMenuTransform.size = {560.0f - 2.0f * kMenuPadding, 340.0f - 2.0f * kMenuPadding - 36.0f};
    m_shopMenu = std::make_unique<HudIconList>(shopMenuTransform, m_font.get(), nullptr,
                                               Hud::Iconos{});  // iconos: createInventoryScreenWidgets

    // --- Cartel de negocio: mismo sitio que la tienda (modos
    // excluyentes), con una ficha de texto encima del menu. ---
    m_businessPanel = std::make_unique<HudPanel>(shopPanelTransform, m_whiteTexture.get(),
                                                 kPanelColor);
    m_businessPanel->setBorder(kBorderColor, 2.0f);

    HudTransform businessTextTransform;
    businessTextTransform.anchor = HudAnchor::Center;  // TIENDA-01: mismo panel centrado
    businessTextTransform.offset = {-220.0f, -210.0f};
    m_businessText = std::make_unique<HudText>(businessTextTransform, m_font.get());

    HudTransform businessMenuTransform;
    businessMenuTransform.anchor = HudAnchor::Center;
    businessMenuTransform.offset = {0.0f, -80.0f};  // bajo la ficha de texto
    businessMenuTransform.size = {540.0f, 80.0f};
    m_businessMenu = std::make_unique<HudCommandMenu>(businessMenuTransform, m_font.get(),
                                                      std::vector<std::string>{});

    // F1 (bitacora 2.18): barra del temporizador de mision, arriba a la
    // derecha, bajo el panel de enemigo. Solo aparece con un timer ACTIVO
    // y NO secreto (los Secretos no se dibujan por definicion); el valor
    // es la fraccion de tiempo restante.
    HudTransform timerTransform;
    timerTransform.anchor = HudAnchor::TopRight;
    timerTransform.offset = {-170.0f, 86.0f};
    timerTransform.size = {160.0f, 10.0f};
    m_timerBar = std::make_unique<HudBar>(timerTransform, m_whiteTexture.get());
    m_timerBar->setMaxValue(1.0f);
    m_timerBar->setBorder(kBorderColor, 1.0f);
    m_timerBar->setVisible(false);
    m_hud.addElement(m_timerBar.get());

    trace("init: widgets construidos OK");
    // Orden de insercion = orden de dibujado (ver HudManager): cada panel
    // antes que lo que lleva encima.
    m_hud.addElement(m_pergamino->capaBaja());  // HUD de exploracion y dialogo
    m_hud.addElement(m_enemyPanel.get());
    m_hud.addElement(m_enemyText.get());
    m_hud.addElement(m_enemyBar.get());
    m_hud.addElement(m_fpsText.get());
    m_hud.addElement(m_hintText.get());
    m_hud.addElement(m_dialoguePanel.get());
    m_hud.addElement(m_dialogue.get());
    m_hud.addElement(m_commandPanel.get());
    m_hud.addElement(m_commandMenu.get());
    m_hud.addElement(m_shopPanel.get());
    m_hud.addElement(m_shopTitle.get());
    m_hud.addElement(m_shopMenu.get());
    m_hud.addElement(m_businessPanel.get());
    m_hud.addElement(m_businessText.get());
    m_hud.addElement(m_businessMenu.get());

    trace("init: HUD compuesto OK");

    // --- G-08 (rodaja inicial): pantalla de titulo ---
    // Con startAtTitle el juego abre en el titulo del PRIMER proyecto del
    // indice, y la campana, en vez de caer directo en el nivel. El estado
    // vive en Game::TitleMenuState (GL-free); aquí solo se construyen los
    // widgets. Si el indice o el manifiesto no están disponibles (assets a
    // medias), se arranca directo como antes: el menú es una comodidad, no
    // una dependencia. El nivel inicial queda cargado detrás del título (se
    // ve el interior del prólogo).
    if (startAtTitle) {
        // H0-01 — el indice ya se escaneo arriba (antes de cargar los
        // catalogos) y sus catalogos ya estan en m_objectCatalog; aquí solo
        // se consume. Si no habia proyecto, arranque directo como antes (el
        // menu es una comodidad, no una dependencia).
        std::unique_ptr<Game::TitleMenuState> title;
        if (!m_projectIndex.projects().empty()) {
            // H0-07 — el titulo sale del manifiesto, no del indice: un juego
            // exportado no es un indice, es UN proyecto (TitleMenuState.h,
            // regla 1). El indice global sigue siendo el listado de trabajo.
            const auto& campana = m_projectIndex.projects().front();
            title = std::make_unique<Game::TitleMenuState>(
                Game::TitleMenuState::fromManifest("assets/proyectos/" + campana.id + ".json",
                                                   /*assetsBase=*/"", /*savesRoot=*/"saves"));
        }
        if (title == nullptr || !title->ok()) {
            trace("init: sin titulo desde manifiesto; arranco directo");
        } else {
            m_title = std::move(title);
            // Ranuras de la campana: el mismo proyecto que enumera el
            // titulo para «Continuar» (saves/<proyecto>/).
            m_projectId = m_projectIndex.projects().front().id;
            setupSaveSlots();

            const int glyphW = m_font->glyphWidth();
            const int glyphH = m_font->glyphHeight();

            // El titulo en si: el que fija el manifiesto (E-11/proyecto).
            // Antes era un rótulo fijo del motor ("MOTOR GRÁFICO · ONEGAI").
            const std::string titleText = m_title->title();
            HudTransform titleTextTransform;
            titleTextTransform.anchor = HudAnchor::TopCenter;
            titleTextTransform.offset = {0.0f, 96.0f};
            titleTextTransform.size = BitmapFont::measureText(titleText, glyphW, glyphH);
            m_titleText = std::make_unique<HudText>(titleTextTransform, m_font.get());
            m_titleText->setText(titleText);
            m_titleText->setColor(Vector4{1.0f, 0.9f, 0.5f, 1.0f});

            // Las entradas apagadas llevan su MOTIVO al lado («Continuar»
            // sin partidas, etc.): un «no» sin por qué parece un error.
            std::vector<std::string> titleOptions;
            for (const auto& item : m_title->items()) {
                titleOptions.push_back(item.enabled ? item.label
                                                    : item.label + " («" + item.reason + "»)");
            }
            const Vector2 titleMenuSize = HudCommandMenu::contentSize(*m_font, titleOptions);
            HudTransform titleMenuTransform;
            titleMenuTransform.anchor = HudAnchor::Center;
            titleMenuTransform.offset = {0.0f, 40.0f};
            titleMenuTransform.size = titleMenuSize;
            m_titleMenu =
                std::make_unique<HudCommandMenu>(titleMenuTransform, m_font.get(), titleOptions);

            HudTransform titlePanelTransform;
            titlePanelTransform.anchor = HudAnchor::Center;
            titlePanelTransform.offset = {0.0f, 40.0f};
            titlePanelTransform.size = {titleMenuSize.x + 2.0f * kMenuPadding,
                                        titleMenuSize.y + 2.0f * kMenuPadding};
            m_titlePanel = std::make_unique<HudPanel>(titlePanelTransform, m_whiteTexture.get(),
                                                      kPanelColor);
            m_titlePanel->setBorder(kBorderColor, 2.0f);

            std::string hintText = "W/S ELEGIR · ENTER ABRIR · ESC SALIR";
            if (!m_title->ok()) {
                hintText += "\n" + m_title->error();
            }
            HudTransform titleHintTransform;
            titleHintTransform.anchor = HudAnchor::BottomCenter;
            titleHintTransform.offset = {0.0f, 56.0f};
            titleHintTransform.size = BitmapFont::measureText(hintText, glyphW, glyphH);
            m_titleHint = std::make_unique<HudText>(titleHintTransform, m_font.get());
            m_titleHint->setText(hintText);
            m_titleHint->setColor(Vector4{0.75f, 0.75f, 0.8f, 1.0f});

            // Orden de inserción = orden de dibujado: el panel primero.
            m_hud.addElement(m_titlePanel.get());
            m_hud.addElement(m_titleText.get());
            m_hud.addElement(m_titleMenu.get());
            m_hud.addElement(m_titleHint.get());
            trace("init: pantalla de título activa");
        }
    }
    // Pantallas de juego (Pause, GameOver, Inventario): existen SIEMPRE, con
    // titulo o sin el. Con --nivel (la prueba del editor, F7) solo se creaban
    // con titulo y ESC+W/S o TAB+flecha dejaban el juego en un puntero nulo.
    m_pauseMenu = std::make_unique<Game::PauseMenu>(Game::PauseMenu::create());
    m_gameOverScreen = std::make_unique<Game::GameOverScreen>(Game::GameOverScreen::create());
    m_inventoryScreen = std::make_unique<Game::InventoryScreen>(*m_session);
    createIconWidgets();
    m_hud.addElement(m_pergamino->capaAlta());  // cuaderno y papiros: encima de todo

    auto sceneStarted = m_scenes.start(makeScene(startAtTitle && m_title != nullptr));
    if (!sceneStarted.isOk()) return sceneStarted;
    m_running = true;
    refreshHud();
    trace("init: COMPLETADO");
    return Result<bool>::Ok(true);
}


void Application::confirmBusinessCommand() {
    const std::size_t selected = m_businessMenu->selectedIndex();
    const bool owned = m_session->ownsBusiness(m_session->currentBusinessId());
    if (!owned) {
        // {COMPRAR, SALIR}
        if (selected == 0) {
            m_session->buyCurrentBusiness();
        } else {
            m_session->closeInteraction();
        }
        return;
    }
    // {SUBIR, BAJAR, SALIR}
    if (selected == 0) {
        m_session->adjustCurrentRent(+10);
    } else if (selected == 1) {
        m_session->adjustCurrentRent(-10);
    } else {
        m_session->closeInteraction();
    }
}

void Application::confirmShopCommand() {
    const std::size_t selected = m_shopMenu->selectedIndex();
    // Mitad de arriba: comprar. Mitad de abajo: vender (m_sellIndices
    // traduce la linea del menu al indice real del inventario, que no
    // coinciden porque las lineas van agrupadas por id).
    if (selected < m_shopSellOffset) {
        m_session->buy(selected);
        return;
    }
    const std::size_t sellLine = selected - m_shopSellOffset;
    if (sellLine < m_sellIndices.size()) {
        m_session->sell(m_sellIndices[sellLine]);
    }
}

void Application::confirmBattleCommand() {
    BattleState* battle = m_session->battle();
    if (battle == nullptr) {
        return;
    }
    // Indices del menu: los tres primeros son comandos de base (Atacar,
    // Pocion, Huir) y a partir del 3 entran las habilidades de la ficha,
    // reconstruidas en refreshHud() desde buildBattleMenuSkillActions().
    // Los IDs de habilidad los resuelve translateToBattleAction (G-13):
    // ninguno escrito a mano aqui (criterio de cierre de H1-01).
    BattleAction action;
    const std::size_t index = m_commandMenu->selectedIndex();
    if (index == 0) {
        action = BattleAction{BattleActionType::Attack, "", 0, ""};
    } else if (index == 1) {
        action = BattleAction{BattleActionType::Item, "", 0, "pocion"};
    } else if (index == 2) {
        action = BattleAction{BattleActionType::Flee, "", 0, ""};
    } else {
        const auto entries = buildBattleMenuSkillActions(
            m_playerSkills, publishSheetSkills(m_playerSkills, m_skillCatalog), *m_player);
        const std::size_t skillIndex = index - 3;
        if (skillIndex >= entries.size()) {
            return;  // defensivo: selectedIndex() ya clampa a options()
        }
        const BattleMenuEntry& entry = entries[skillIndex];
        if (!entry.available) {
            return;  // fila bloqueada: el motivo ya se ve en la propia opcion
        }
        const auto targets = selectTargetsFor(entry, battle->allies(), battle->enemies(), 0);
        const TargetOption* chosen = nullptr;
        for (const auto& o : targets) {
            if (o.alive) {
                chosen = &o;
                break;
            }
        }
        if (chosen == nullptr) {
            return;  // sin objetivo valido en el bandol del hechizo
        }
        std::string cancelReason;
        if (!translateToBattleAction(entry, *chosen, battle->enemies(), action, cancelReason)) {
            return;  // G-13 cancela antes de gastar recursos
        }
    }
    battle->resolveAllyAction(0, action);
    // Turno enemigo salvo que la accion del jugador ya haya cerrado el
    // combate (victoria o huida): sin esto, un enemigo ya muerto podria
    // "responder" -- BattleState lo ignora igualmente (no-op tras el
    // desenlace), pero dejarlo explicito aqui hace evidente el orden del
    // turno.
    if (battle->outcome() == BattleOutcome::InProgress) {
        battle->resolveEnemyTurn();
        // H0-06 — una ronda completa (aliado + enemigos): los estados
        // alterados avanzan un tick (dano por ronda del DOT, y caducan
        // cuando agotan las rondas de la carta). Lo lógico habría sido
        // ticar al empezar la ronda siguiente, pero el bucle es este:
        // cada confirmBattleCommand es exactamente una ronda.
        battle->tickRound();
    }
    // Aplica el desenlace al mundo (enemigo eliminado / GameOver / vuelta
    // a exploracion). No-op si el combate sigue.
    m_session->syncBattleOutcome();
}

// --- H0-05: guardado rapido y «Continuar» sobre el servicio de ranuras ---
//
// La Application es quien guarda y carga porque es quien conoce las RUTAS
// (la sesion no hace I/O, ver GameSession.h) y quien sobrevive al cambio
// de nivel. El servicio (Game::SaveSlots) es quien sabe DONDE viven las
// ranuras de cada proyecto (saves/<proyecto>/). GameSession solo sabe
// fotografiarse y volver a su sitio.

void Application::setupSaveSlots() {
    m_saveSlots = std::make_unique<Game::SaveSlots>("saves", m_projectId);
    m_saveSlots->refresh();
}

bool Application::quickSave() {
    if (m_session == nullptr || m_saveSlots == nullptr) {
        return false;
    }
    const Game::SaveGate puerta = Game::CanSaveNow(m_session->mode(), /*eventRunning=*/false);
    if (!puerta.allowed) {
        m_session->logNote("No se puede guardar: " + puerta.reason);
        return false;
    }
    const SaveGameData data = m_session->captureSaveGame(m_currentLevelPath);
    auto guardado = m_saveSlots->save(Game::SaveSlots::kQuickSlot, data);
    if (!guardado.isOk()) {
        m_session->logNote("No se pudo guardar: " + guardado.errorMessage());
        return false;
    }
    m_session->logNote("Partida guardada.");
    return true;
}

bool Application::loadSlot(int index) {
    if (m_session == nullptr || m_saveSlots == nullptr) {
        return false;
    }
    const Game::SaveSlot* ranura = m_saveSlots->find(index);
    if (ranura == nullptr || !ranura->loadable()) {
        m_session->logNote("No hay ninguna partida cargable en la ranura " +
                           std::to_string(index));
        return false;
    }
    auto leida = m_saveSlots->load(index);
    if (!leida.isOk()) {
        m_session->logNote("No se pudo cargar: " + leida.errorMessage());
        return false;
    }
    const SaveGameData data = leida.value();  // copia: el dato entra en la lambda
    const auto requested = m_scenes.requestReplace(makeScene(false, [this, data] {
        auto loaded = loadLevel(data.levelPath, false, GridCoord{}, [this, &data] {
            m_narrativeState.reset();
            applyNarrativeState(data, m_narrativeState);
        }, &data);
        if (loaded.isOk()) m_session->logNote("Partida cargada.");
        return loaded;
    }));
    return requested.isOk();
}

bool Application::quickLoad() { return loadSlot(Game::SaveSlots::kQuickSlot); }

int Application::newestLoadableSlot() {
    if (m_saveSlots == nullptr) {
        return -1;
    }
    m_saveSlots->refresh();
    // PERGAMINO-01 — la mas reciente de todas, la rapida incluida: la pausa
    // solo guarda ahi, y «Cargar último guardado» (derrota) no encontraba
    // nada. Mismo criterio que «Continuar» en el titulo (savedAt ordena).
    const Game::SaveSlot* mejor = m_saveSlots->quick().loadable() ? &m_saveSlots->quick() : nullptr;
    for (const Game::SaveSlot& ranura : m_saveSlots->slots()) {
        if (ranura.loadable() && (mejor == nullptr || ranura.savedAt > mejor->savedAt)) mejor = &ranura;
    }
    return mejor != nullptr ? mejor->index : -1;
}

// --- H0-04: pausa ---
// requestPause/requestResume delegan en GameSession (el modelo autoritativo
// del modo): la vista toca la tecla y la pantalla se abre, pero quien
// congela el mundo es la sesion.

void Application::requestPause() {
    if (m_session != nullptr) {
        m_session->pause();
    }
}

void Application::requestResume() {
    if (m_session != nullptr) {
        m_session->resume();
    }
}

void Application::processInput() {
    using Engine::Input::InputAction;
    GLFWwindow* win = m_window->handle();
    const auto input = m_window->hasInputFocus() ? m_input.update(readGameKeyboard(win)) : m_input.releaseAll();
    if (m_nuevaPartida && m_nuevaPartida->activa()) { m_nuevaPartida->procesar(input); refreshHud(); return; }
    const bool canWalk = m_window->hasInputFocus() && !isAtTitle() && m_session &&
        m_session->mode() == GameMode::Exploration && !m_showInventory &&
        !m_scenes.hasPendingTransition() && !input.pressed(InputAction::Quit) &&
        !input.pressed(InputAction::ToggleInventory) && !input.pressed(InputAction::Interact) &&
        !input.pressed(InputAction::QuickLoad);
    const GridCoord step = m_player->movementCommand(input, glfwGetTime(), canWalk);
    // La marca AFK se actualiza únicamente si hubo actividad real. Antes se
    // actualizaba por el mero hecho de sondear cada frame, de modo que el
    // temporizador narrativo nunca llegaba a considerar al jugador ausente.
    if (input.hasActivity()) {
        m_lastInput = std::chrono::steady_clock::now();
    }

    if (input.pressed(InputAction::Quit)) {
        const auto mode = m_session ? m_session->mode() : GameMode::Exploration;
        switch (PlayerControls::escapeAction(mode, isAtTitle() || !m_session, m_showInventory)) {
            case PlayerEscapeAction::Quit: m_running = false; break;
            case PlayerEscapeAction::CloseInventory: m_showInventory = false; break;
            case PlayerEscapeAction::Pause: requestPause(); break;
            // En las opciones, ESC vuelve a la pausa (el pie del papiro lo dice).
            case PlayerEscapeAction::Resume: if (m_options) m_options.reset(); else requestResume(); break;
            case PlayerEscapeAction::CloseInteraction: m_session->closeInteraction(); break;
            case PlayerEscapeAction::None: break;
        }
        return;
    }

    // --- G-08 (rodaja inicial): pantalla de titulo ---
    // El mismo lenguaje de menú que en combate/tienda (W/S + ENTER); el
    // ESC ya salió del proceso arriba, igual que la entrada "Salir".
    if (isAtTitle()) {
        if (input.pressed(InputAction::MenuUp)) {
            m_title->moveUp();
            m_titleMenu->setSelectedIndex(m_title->selected());
        }
        if (input.pressed(InputAction::MenuDown)) {
            m_title->moveDown();
            m_titleMenu->setSelectedIndex(m_title->selected());
        }
        if (input.pressed(InputAction::Confirm)) {
            confirmTitleSelection();
        }
        return;
    }

    if (m_session->mode() == GameMode::Exploration && !m_showInventory) {
        // H0-05 — Guardado rapido. Solo aqui: en combate, dialogo o
        // tienda las teclas no hacen nada (ver quickSave/loadSlot en el .h).
        if (input.pressed(InputAction::QuickSave)) {
            quickSave();
        }
        if (input.pressed(InputAction::QuickLoad)) {
            quickLoad();
            // quickLoad ha solicitado el cambio: no se sigue leyendo
            // input contra el estado viejo en este mismo frame.
            return;
        }

        // E: hablar con el NPC de al lado, o cruzar la puerta que se
        // pisa. La transicion la ejecuta update() (ver
        // applyPendingTransition): cambiar de nivel A MITAD de
        // processInput destruiria la sesion que se esta consultando.
        if (input.pressed(InputAction::Interact)) {
            m_session->interact();
        }

        // La sesion manda sobre colisiones y pasos; el sprite solo interpola.
        if (step.x != 0 || step.y != 0) {
            if (!m_session->tryMovePlayer(step.x, step.y)) { m_player->bump(step); return; }
            m_player->moveTo(m_session->playerPosition());
        }
    } else if (m_session->mode() == GameMode::Battle) {
        if (input.pressed(InputAction::MenuUp)) m_commandMenu->moveUp();
        if (input.pressed(InputAction::MenuDown)) m_commandMenu->moveDown();
        if (input.pressed(InputAction::Confirm)) {
            confirmBattleCommand();
        }
    } else if (m_session->mode() == GameMode::Shop) {
        // Mismo esquema de teclas que el combate (W/S + ENTER): el
        // jugador no tiene que aprender dos lenguajes de menu.
        if (input.pressed(InputAction::MenuUp)) m_shopMenu->moveUp();
        if (input.pressed(InputAction::MenuDown)) m_shopMenu->moveDown();
        if (input.pressed(InputAction::Confirm)) {
            confirmShopCommand();
        }
        if (input.pressed(InputAction::Cancel)) {
            m_session->closeInteraction();
        }
    } else if (m_session->mode() == GameMode::Business) {
        if (input.pressed(InputAction::MenuUp)) m_businessMenu->moveUp();
        if (input.pressed(InputAction::MenuDown)) m_businessMenu->moveDown();
        if (input.pressed(InputAction::Confirm)) {
            confirmBusinessCommand();
        }
        if (input.pressed(InputAction::Cancel)) {
            m_session->closeInteraction();
        }
    } else if (m_session->mode() == GameMode::Dialogue) {
        // PERGAMINO-01 — ENTER pasa pagina en la hoja del dialogo y cierra
        // en la ultima (la que dice «Cerrar»).
        if ((input.pressed(InputAction::Confirm) || input.pressed(InputAction::Interact)) &&
            !(m_pergamino && m_pergamino->listo() && m_pergamino->interfaz().pasaPaginaDialogo())) {
            m_session->closeInteraction();
        }
    } else if (m_session->mode() == GameMode::Pause) {
        // H1-03 — si el submenu de opciones esta abierto, sus teclas van a
        // el: arriba/abajo navegan, izquierda/derecha ajustan el valor de
        // la fila (volumenes e idioma), Confirmar aplica la fila y Cancelar
        // (ESC) vuelve al menu de pausa.
        if (m_options) {
            if (input.pressed(InputAction::MenuUp)) m_options->moveUp();
            if (input.pressed(InputAction::MenuDown)) m_options->moveDown();
            if (input.pressed(InputAction::MenuLeft)) {
                adjustOptionsLeft();
            }
            if (input.pressed(InputAction::MenuRight)) {
                adjustOptionsRight();
            }
            if (input.pressed(InputAction::Confirm)) {
                confirmOptionsCommand();
            }
            if (input.pressed(InputAction::Cancel)) m_options.reset();
        } else {
            // Navegación del menú de pausa (el papiro lee m_pauseMenu).
            if (input.pressed(InputAction::MenuUp)) m_pauseMenu->moveUp();
            if (input.pressed(InputAction::MenuDown)) m_pauseMenu->moveDown();
            if (input.pressed(InputAction::Confirm)) {
                confirmPauseCommand();
                if (!m_session) return;  // «Volver al título»: ya no hay sesion
            }
            if (input.pressed(InputAction::Cancel)) {
                m_session->closeInteraction(); // Cerrar pausa
            }
        }
    } else if (m_session->mode() == GameMode::GameOver) {
        // Navegación de pantalla de Game Over (la pinta el papiro).
        if (input.pressed(InputAction::MenuUp)) m_gameOverScreen->moveUp();
        if (input.pressed(InputAction::MenuDown)) m_gameOverScreen->moveDown();
        if (input.pressed(InputAction::Confirm)) {
            confirmGameOverCommand();
            if (!m_session) return;  // «Volver al título»
        }
    }

    // Inventario (toggle con TAB, solo en exploracion)
    if (m_session->mode() == GameMode::Exploration && input.pressed(InputAction::ToggleInventory)) {
        m_showInventory = !m_showInventory;
        if (m_showInventory) {
            m_inventoryScreen = std::make_unique<Game::InventoryScreen>(*m_session);
        }
    }

    // Navegación de inventario (solo si está abierto)
    if (m_showInventory) {
        // Pasar hoja sin vuelta circular: en la primera y la ultima hoja
        // las flechas no hacen nada (MODELO_VISUAL.md §13.3).
        const int hoja = static_cast<int>(m_inventoryScreen->focus());
        if (input.pressed(InputAction::MenuLeft) && hoja > 0) m_inventoryScreen->moveTabLeft();
        if (input.pressed(InputAction::MenuRight) && hoja + 1 < static_cast<int>(Game::InventoryFocus::COUNT))
            m_inventoryScreen->moveTabRight();
        if (input.pressed(InputAction::MenuUp)) m_inventoryScreen->moveUp();
        if (input.pressed(InputAction::MenuDown)) m_inventoryScreen->moveDown();
        if (input.pressed(InputAction::Confirm)) {
            confirmInventoryCommand();
        }
        if (input.pressed(InputAction::Cancel) && !input.pressed(InputAction::ToggleInventory)) {
            m_showInventory = false;
        }
    }
}


void Application::confirmTitleSelection() {
    if (!isAtTitle() || !m_title || m_scenes.hasPendingTransition()) return;
    // H0-07 — confirm() sobre una entrada apagada devuelve None y deja el
    // motivo en message(); las apagadas NO se ejecutan (regla 3).
    const auto action = m_title->confirm();
    if (action == Game::TitleCommand::None) {
        if (m_titleHint != nullptr) {
            m_titleHint->setText(m_title->selectedItem().reason);
        }
        return;
    }
    if (action == Game::TitleCommand::Quit) {
        m_running = false;
    } else if (action == Game::TitleCommand::NewGame) {
        // El nivel inicial ya queda montado detras del titulo (init carga
        // loadLevel primero): dejar el titulo es devolver la partida viva.
        if (!m_nuevaPartida || !m_nuevaPartida->abrir().isOk()) m_scenes.requestReplace(makeScene(false));
    } else if (action == Game::TitleCommand::Continue) {
        // «Continuar» apunta a la ranura cargable mas reciente del
        // proyecto (la calculo TitleMenuState desde el mismo servicio).
        loadSlot(m_title->continueSlot());
    } else if (action == Game::TitleCommand::Options) {
        // G-10 — sin pantalla propia aun; el hint cuenta lo que queda.
        if (m_titleHint != nullptr) {
            m_titleHint->setText("Opciones: sin pantalla propia aun (G-10)");
        }
    }
}

// GDB-12.5 — Confirmar comando del menú de pausa
void Application::confirmPauseCommand() {
    if (!m_pauseMenu || m_scenes.hasPendingTransition()) return;
    const auto action = m_pauseMenu->confirm();
    if (action == Game::PauseAction::Quit) {
        m_running = false;
    } else if (action == Game::PauseAction::Resume) {
        // H0-04 — requestResume(): closeInteraction() era un no-op para el
        // modo Pause, dejando el juego clavado en el menu.
        requestResume();
    } else if (action == Game::PauseAction::Character || action == Game::PauseAction::Inventory) {
        // PERGAMINO-01 — closeInteraction() no sale de la pausa: el cuaderno
        // se abria debajo del menu y no se veia. Se reanuda y se abre el
        // cuaderno por su hoja (Personaje -> FICHA, Inventario -> INVENTARIO).
        requestResume();
        m_showInventory = true;
        m_inventoryScreen = std::make_unique<Game::InventoryScreen>(*m_session);
        for (int i = 0; action == Game::PauseAction::Character && i < static_cast<int>(Game::InventoryFocus::COUNT) &&
                        m_inventoryScreen->focus() != Game::InventoryFocus::Status; ++i)
            m_inventoryScreen->moveTabRight();
    } else if (action == Game::PauseAction::Save) {
        // H0-05: la ranura rapida del proyecto. El papiro dice como ha ido.
        const bool ok = quickSave();
        if (m_pergamino)
            m_pergamino->interfaz().avisaPausa(ok, ok ? "Partida guardada" : "No se ha podido guardar",
                                               ok ? detalleGuardado(m_pergamino->interfaz().zona())
                                                  : motivoDeLaNota(*m_session));
    } else if (action == Game::PauseAction::Load) {
        if (!quickLoad() && m_pergamino)
            m_pergamino->interfaz().avisaPausa(false, "No se ha podido cargar", motivoDeLaNota(*m_session));
    } else if (action == Game::PauseAction::Options) {
        // H1-03 — el submenu de opciones se abre encima de la pausa; el
        // menu de pausa no se cierra, asi «Volver» cae de vuelta en el.
        m_options = std::make_unique<Game::OptionsState>(Game::OptionsState::create());
    } else if (action == Game::PauseAction::Title) {
        // Volver al título: cerrar sesión actual e ir al título
        m_session.reset();
        m_scenes.requestReplace(makeScene(true));
    }
}

// H1-03 — Confirmar la fila elegida del submenu de opciones.
void Application::confirmOptionsCommand() {
    if (!m_options || m_scenes.hasPendingTransition()) return;
    const auto action = m_options->confirm();
    if (action == Game::OptionsAction::Back) {
        // Volver: se cierra el submenu y el menu de pausa vuelve a mandar.
        m_options.reset();
    } else if (action == Game::OptionsAction::ShowControls) {
        // La pantalla de controles es otro paquete (H1-03): por ahora se
        // anuncia al pie del papiro, como ya hace el titulo en su hint.
        if (m_pergamino) m_pergamino->interfaz().avisaPausa(false, "Controles: aún sin pantalla propia", "");
    }
    // OptionsAction::None: las filas de volumen/idioma se ajustan con
    // izquierda/derecha y no se confirman.
}

// H1-05 — Ajustar Izq/Der en la fila IDIOMA aplica el idioma al Locale.
void Application::applyOptionsLanguage() {
    if (!m_options || !m_locale) return;
    if (m_options->selectedEntry().key != "language") return;
    (void)Game::OptionsLocaleBridge::applyLanguage(*m_options, *m_locale);
}

// H1-05 — ajuste Izq/Der de la fila seleccionada del submenu de opciones:
// el valor se cambia, el widget se sincroniza y, si la fila es IDIOMA, el
// idioma se aplica al Locale.
void Application::adjustOptionsLeft() {
    if (!m_options) return;
    m_options->adjustLeft();
    applyOptionsLanguage();
}

void Application::adjustOptionsRight() {
    if (!m_options) return;
    m_options->adjustRight();
    applyOptionsLanguage();
}

// GDB-12.4 — Confirmar acción en Game Over
void Application::confirmGameOverCommand() {
    if (!m_gameOverScreen || m_scenes.hasPendingTransition()) return;
    const auto action = m_gameOverScreen->confirm();
    if (action == Game::GameOverAction::Load) {
        // H0-05 — la ranura enumerada mas reciente del proyecto.
        loadSlot(newestLoadableSlot());
    } else if (action == Game::GameOverAction::Title) {
        m_session.reset();
        m_scenes.requestReplace(makeScene(true));
    }
}


