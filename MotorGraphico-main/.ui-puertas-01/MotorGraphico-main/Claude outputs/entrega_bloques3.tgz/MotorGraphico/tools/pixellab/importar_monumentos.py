#!/usr/bin/env python3
"""BLOQUES-03 — Monumentos de PixelLab (un sprite grande por edificio) como
hojas de tiras para Game::Monumentos / Render::MonumentosNivel.

Lee assets/textures/pixellab/monumentos.json:
    {"monumentos": [{"id": "coliseo", "imagen": "lote10/coliseo.png", "tiles": ["viejo_coliseo"],
                     "ancho": 8, "alto": 6, "pixellab_id": "..."}]}
Para cada uno: recorta el margen transparente, lo escala (vecino mas proximo)
a la anchura de su huella en pantalla, (ancho + alto) * 32 px, lo deja en una
hoja de tiras de 32 px de ancho (una fila, assets/textures/monumentos/<id>.png
+ .json con el formato de las hojas de props) y calcula el anclaje: el punto
mas bajo del dibujo, en el centro, es la esquina delantera de la huella.
Escribe assets/textures/monumentos.json (lo que lee el motor) y da de alta
cada hoja en sprites.json.

    python3 tools/pixellab/importar_monumentos.py
"""
import json
import math
import sys
from pathlib import Path

from PIL import Image

ROOT = Path(__file__).resolve().parents[2]
TEX = ROOT / "assets/textures"
TIRA = 32


def prepara(img, ancho, alto):
    """La imagen recortada y escalada a la anchura de la huella; devuelve (hoja, anclaje)."""
    img = img.convert("RGBA")
    caja = img.getbbox()
    if caja is None:
        raise SystemExit("imagen vacia")
    img = img.crop(caja)
    objetivo = (ancho + alto) * TIRA
    factor = objetivo / img.width
    img = img.resize((objetivo, max(1, round(img.height * factor))), Image.NEAREST)
    columnas = math.ceil(img.width / TIRA)
    hoja = Image.new("RGBA", (columnas * TIRA, img.height), (0, 0, 0, 0))
    hoja.paste(img, (0, 0), img)
    # Anclaje: el pixel opaco mas bajo de la mitad central es la esquina delantera.
    alpha = hoja.getchannel("A")
    centro = hoja.width // 2
    ay = hoja.height - 1
    for y in range(hoja.height - 1, -1, -1):
        if any(alpha.getpixel((x, y)) > 0 for x in range(max(0, centro - 8), min(hoja.width, centro + 8))):
            ay = y + 1
            break
    return hoja, (centro, ay), columnas


def importar(indice):
    indice = Path(indice)
    datos = json.loads(indice.read_text())
    (TEX / "monumentos").mkdir(exist_ok=True)
    registro = json.loads((TEX / "sprites.json").read_text())
    salida = []
    for m in datos["monumentos"]:
        hoja, (ax, ay), columnas = prepara(Image.open(indice.parent / m["imagen"]), int(m["ancho"]), int(m["alto"]))
        hid = f"monumento_{m['id']}"
        hoja.save(TEX / "monumentos" / f"{m['id']}.png")
        (TEX / "monumentos" / f"{m['id']}.json").write_text(json.dumps({
            "_nota": "Monumento de PixelLab en tiras (tools/pixellab/importar_monumentos.py): no editar a mano. Una fila; cada frame es una tira de 32 px de ancho por todo el alto. TextureManager invierte los PNG al cargarlos.",
            "generador": "tools/pixellab/importar_monumentos.py",
            "image": f"{m['id']}.png", "frameSize": [TIRA, hoja.height], "columns": columnas, "rows": 1,
            "frames": {f"{m['id']}_tira_{k + 1}": k + 1 for k in range(columnas)},
        }, ensure_ascii=False, indent=2) + "\n")
        if not any(h["id"] == hid for h in registro["hojas"]):
            registro["hojas"].append({"id": hid, "manifiesto": f"textures/monumentos/{m['id']}.json"})
        salida.append({"id": m["id"], "hoja": hid, "tiles": m["tiles"], "ancho": int(m["ancho"]), "alto": int(m["alto"]),
                       "tiraAncho": TIRA, "altoHoja": hoja.height, "columnas": columnas, "anclaje": {"x": ax, "y": ay},
                       "pixellab_id": m.get("pixellab_id", "")})
        print(f"{m['id']}: hoja {hoja.width}x{hoja.height}, {columnas} tiras, anclaje ({ax}, {ay})")
    (TEX / "sprites.json").write_text(json.dumps(registro, ensure_ascii=False, indent=2) + "\n")
    (TEX / "monumentos.json").write_text(json.dumps({
        "_nota": "BLOQUES-03 — edificios con sprite propio (Game::Monumentos): no editar a mano, lo escribe tools/pixellab/importar_monumentos.py. Una huella del mapa que mida ancho x alto celdas de esos tiles se dibuja con la hoja en tiras; si no mide eso, con bloques.",
        "tileset": "terreno_mundo", "indiceTileset": "textures/terreno_iso.json", "monumentos": salida,
    }, ensure_ascii=False, indent=2) + "\n")


if __name__ == "__main__":
    importar(sys.argv[1] if len(sys.argv) > 1 else TEX / "pixellab/monumentos.json")
