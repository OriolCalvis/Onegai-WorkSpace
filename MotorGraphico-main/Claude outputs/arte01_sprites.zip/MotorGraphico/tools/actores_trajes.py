"""Materiales, prendas especiales y trajes de los actores por capas."""
from actores_pintura import Material as M, pintar, top_pie, _es_contorno

MATERIALES = {m.nombre: m for m in [
    # telas
    M("tunica_verde", "#8cbf5a", "#5a9442", "#3a6a33", "#1f3b1c", "#142814"),
    M("tunica_azul", "#78a6e0", "#4a74b8", "#314f86", "#1b2c4d", "#101b30"),
    M("tunica_roja", "#e07a62", "#b04a38", "#7e3026", "#461a14", "#2e100c"),
    M("tunica_parda", "#c9a26a", "#9c7646", "#6e522f", "#3e2e1a", "#291e10"),
    M("tabardo_azul", "#5f86c8", "#3a5fa0", "#28437a", "#172a4d", "#0e1a30"),
    M("lino", "#f2ead2", "#d9ccaa", "#b3a47e", "#6e6248", "#4a412f"),
    M("chaleco_marron", "#9a6a44", "#744c30", "#523420", "#2e1d12", "#1f130b"),
    M("habito_purpura", "#6e5480", "#4c3a5c", "#342642", "#1d1426", "#120c18"),
    M("vestido_teja", "#d07a64", "#a8513f", "#77352a", "#421c16", "#2b110d"),
    M("lana_purpura", "#7a5a8c", "#553d66", "#3a2848", "#1f1428", "#140c1a"),
    M("pantalon_pardo", "#a07b52", "#7a5a3c", "#553d29", "#33241a", "#221710"),
    M("pantalon_gris", "#7d7f86", "#5b5d64", "#404248", "#25262a", "#17181b"),
    M("pantalon_oliva", "#8a8a5a", "#6a6a42", "#4a4a2e", "#2b2b1a", "#1c1c10"),
    # cuero, cuerda y metal
    M("cuero", "#b07a45", "#8a5a30", "#633f22", "#3a2412", "#26170b"),
    M("cuero_oscuro", "#7a5238", "#553624", "#3a2418", "#1e120b", "#140b06"),
    M("guante", "#8a6242", "#66462e", "#48301f", "#2a1b10", "#1c110a"),
    M("zapato", "#6e4a30", "#4e3320", "#362214", "#1e120b", "#140b06"),
    M("sandalia", "#5a4030", "#3e2a1e", "#2a1c14", "#160e09", "#0e0906"),
    M("cuerda", "#e0cfa0", "#c2ab74", "#96804e", "#54462a", "#382e1a"),
    M("laton", "#ffe28a", "#e0b040", "#a87a22", "#5a3c10"),
    M("oro_emblema", "#ffe98a", "#f0c030", "#b88a1a", "#6a4a0a"),
    M("acero", "#eef3f6", "#b4c0c8", "#7b8893", "#3a424a", "#24292e"),
    M("malla", "#c9d1d6", "#8f9aa3", "#5d6770", "#2e343a", "#1c2025"),
    # pelo
    M("pelo_castano", "#a0673a", "#7a4a28", "#56321c", "#2e1a0e", "#1f1109"),
    M("pelo_rubio", "#f0d890", "#d4b060", "#a8843a", "#5c4420", "#3e2c14"),
    M("pelo_negro", "#5a5a66", "#3a3a44", "#26262e", "#141418", "#0a0a0e"),
    M("pelo_pelirrojo", "#e8904a", "#c0602a", "#8a401c", "#4a200e", "#321508"),
    M("pelo_oscuro", "#8a5a3a", "#5e3a24", "#3e2416", "#22140a", "#160c06"),
    M("habito_gris", "#6a6a70", "#4a4a52", "#33333a", "#1a1a20", "#101014"),
    M("lana_gris", "#76767e", "#55555e", "#3a3a42", "#1e1e24", "#121216"),
    # piel (luz, base, sombra, contorno suave, contorno duro)
    M("piel_clara", "#ffebc6", "#fad2a9", "#d78b64", "#77432e", "#572e1d"),
    M("piel_morena", "#e8b98a", "#c98f5e", "#9a6440", "#5a3520", "#3e2414"),
    M("piel_palida", "#eee2d6", "#d6c4b4", "#a89080", "#5e4640", "#40302b"),
]}

OJOS = {
    "azul": {},  # los del cuerpo base
    "marron": {"i1": (46, 28, 18), "i2": (82, 50, 28), "i3": (120, 78, 42)},
    "verde": {"i1": (20, 70, 40), "i2": (30, 110, 60), "i3": (60, 150, 80)},
    # brillo ambar bajo la capucha: el blanco tambien queda en penumbra
    "ambar": {"i1": (160, 90, 10), "i2": (235, 160, 30), "i3": (255, 225, 110),
              "w1": (86, 64, 92), "w2": (98, 74, 104), "w3": (110, 86, 116)},
}


# --- prendas que no siguen la silueta ------------------------------------

def _tramo_torso(lab, tono, y):
    xs = [x for x in range(64) if lab[y, x] == "t" and not _es_contorno(tono[y, x])]
    return (min(xs), max(xs)) if xs else None


def _filas_torso(ctx):
    lab, cint = ctx["lab"], ctx["cint"]
    ys = [y for y in range(64) if (lab[y] == "t").any()]
    return (min(ys), cint) if ys else (None, None)


def bandolera(material):
    """Correa cruzada del hombro a la cadera (dos pixeles: cuero y su sombra)."""
    def fn(ctx):
        lab, tono, d = ctx["lab"], ctx["tono"], ctx["dir"]
        m = ctx["mat"][material]
        y0, y1 = _filas_torso(ctx)
        if y0 is None:
            return
        ini, fin = {"abajo": (0.1, 0.9), "arriba": (0.9, 0.1),
                    "derecha": (0.25, 0.8), "izquierda": (0.75, 0.2)}[d]
        y0 += 1
        for y in range(y0, y1):
            tr = _tramo_torso(lab, tono, y)
            if not tr:
                continue
            f = ini + (fin - ini) * (y - y0) / max(1, (y1 - 1 - y0))
            x = int(round(tr[0] + f * (tr[1] - tr[0])))
            for dx, t in ((0, "s"), (1, "d")):
                if lab[y, x + dx] == "t" and not _es_contorno(tono[y, x + dx]):
                    pintar(ctx, y, x + dx, m, t if tono[y, x + dx] != "H" or t == "d" else "H")
    return fn


def tabardo(material_malla, material_emblema):
    """Tabardo de la guardia: hombros de malla y una cruz de oro en el pecho."""
    def fn(ctx):
        lab, tono, d = ctx["lab"], ctx["tono"], ctx["dir"]
        malla, oro = ctx["mat"][material_malla], ctx["mat"][material_emblema]
        y0, y1 = _filas_torso(ctx)
        if y0 is None:
            return
        for y in range(y0, y0 + 3):  # hombros de malla (patron de anillas)
            for x in range(64):
                if lab[y, x] == "t":
                    t = tono[y, x]
                    pintar(ctx, y, x, malla, "O" if _es_contorno(t) else ("s" if (x + y) % 2 else "d"))
        if d not in ("abajo", "arriba"):
            return
        tr = _tramo_torso(lab, tono, y0 + 5)
        if not tr:
            return
        cx = (tr[0] + tr[1]) // 2
        for y in range(y0 + 4, y1):
            if lab[y, cx] == "t":
                pintar(ctx, y, cx, oro, "s")
        yb = y0 + 6
        for x in (cx - 1, cx + 1):
            if lab[yb, x] == "t":
                pintar(ctx, yb, x, oro, "d")
    return fn


def chaleco(material):
    """Chaleco abierto: cubre el torso salvo la camisa del centro (o del frente)."""
    def fn(ctx):
        lab, tono, d = ctx["lab"], ctx["tono"], ctx["dir"]
        m = ctx["mat"][material]
        y0, y1 = _filas_torso(ctx)
        if y0 is None:
            return
        for y in range(y0 + 1, y1):
            tr = _tramo_torso(lab, tono, y)
            if not tr:
                continue
            cx = (tr[0] + tr[1]) / 2
            for x in range(64):
                if lab[y, x] != "t":
                    continue
                t = tono[y, x]
                abierto = ((d == "abajo" and abs(x - cx) <= 1) or
                           (d == "derecha" and x >= tr[1] - 1) or
                           (d == "izquierda" and x <= tr[0] + 1))
                if abierto:
                    continue
                borde = ((d == "abajo" and abs(x - cx) <= 2) or
                         (d == "derecha" and x == tr[1] - 2) or
                         (d == "izquierda" and x == tr[0] + 2))
                if _es_contorno(t):
                    pintar(ctx, y, x, m, "O")
                else:
                    pintar(ctx, y, x, m, "d" if borde else ("s" if t == "H" else t))
    return fn


def delantal(material):
    """Delantal de cintura: de frente cubre el centro de la falda; de lado, el
    borde delantero; de espaldas solo se ve el lazo sobre el cinturon."""
    def fn(ctx):
        lab, px, d, cint = ctx["lab"], ctx["px"], ctx["dir"], ctx["cint"]
        m = ctx["mat"][material]
        pies = [v for v in (top_pie(lab, "f"), top_pie(lab, "F")) if v is not None]
        if cint is None or not pies:
            return
        fondo = min(pies) - 3
        for y in range(cint, fondo + 1):
            xs = [x for x in range(64) if px[y, x, 3] and ctx["cubre"].get((y, x)) is not None]
            if not xs:
                continue
            x0, x1 = min(xs), max(xs)
            if d == "arriba":
                if y == cint:  # lazo
                    cx = (x0 + x1) // 2
                    for x in (cx - 1, cx, cx + 1):
                        pintar(ctx, y, x, m, "s" if x != cx else "d")
                continue
            if d == "abajo":
                cx = (x0 + x1) / 2
                a, b = int(round(cx - 3)), int(round(cx + 3))
            elif d == "derecha":
                a, b = x1 - 3, x1 - 1
            else:
                a, b = x0 + 1, x0 + 3
            for x in range(a, b + 1):
                borde = x in (a, b) or y == fondo
                pintar(ctx, y, x, m, "d" if borde else ("H" if y == cint + 1 else "s"))
    return fn


# --- trajes ----------------------------------------------------------------

TRAJES = {
    "aventurero": {
        "nombre": "Aventurero (jugador)",
        "partes": {"t": "tunica_verde", "a": "tunica_verde", "A": "tunica_verde",
                   "p": "pantalon_pardo", "l": "pantalon_pardo", "L": "pantalon_pardo"},
        "bajo": ("tunica_verde", 2),
        "cinturon": ("cuero", "laton", 0),
        "botas": ("cuero_oscuro", 2),
        "extras": [bandolera("cuero")],
        "tocado": ("PELO_CORTO", "pelo_castano", None),
    },
    "guardia": {
        "nombre": "Guardia de Boundington",
        "partes": {"t": "tabardo_azul", "a": "malla", "A": "malla",
                   "m": "guante", "M": "guante",
                   "p": "pantalon_gris", "l": "pantalon_gris", "L": "pantalon_gris"},
        "bajo": ("tabardo_azul", 3),
        "cinturon": ("cuero_oscuro", "acero", 0),
        "botas": ("acero", 3),
        "extras": [tabardo("malla", "oro_emblema")],
        "ojos": OJOS["marron"],
        "tocado": ("CHAPEL", "acero", "malla"),
    },
    "aldeano": {
        "nombre": "Aldeano",
        "partes": {"t": "lino", "a": "lino", "A": "lino",
                   "p": "pantalon_oliva", "l": "pantalon_oliva", "L": "pantalon_oliva"},
        "cinturon": ("cuero", None, 0),
        "botas": ("zapato", 0),
        "extras": [chaleco("chaleco_marron")],
        "piel": "piel_morena",
        "ojos": OJOS["marron"],
        "tocado": ("PELO_CORTO", "pelo_rubio", None),
    },
    "cultista": {
        "nombre": "Perdido encapuchado (cultista)",
        "partes": {"t": "habito_purpura", "a": "habito_purpura", "A": "habito_purpura",
                   "p": "habito_purpura", "l": "habito_purpura", "L": "habito_purpura"},
        "habito": "habito_purpura",
        "cinturon": ("cuerda", None, 3),
        "botas": ("sandalia", 0),
        "piel": "piel_palida",
        "ojos": OJOS["ambar"],
        "tocado": ("CAPUCHA", "lana_purpura", None),
    },
}


def _variante(base, **cambios):
    t = dict(TRAJES[base])
    t.update(cambios)
    return t


def _con_partes(base, mapa):
    """Copia de las partes del traje base con los materiales sustituidos."""
    return {e: mapa.get(m, m) for e, m in TRAJES[base]["partes"].items()}


TRAJES["aventurero_azul"] = _variante(
    "aventurero", nombre="Aventurero (tinte azul)",
    partes=_con_partes("aventurero", {"tunica_verde": "tunica_azul"}),
    bajo=("tunica_azul", 2), tocado=("PELO_CORTO", "pelo_negro", None), ojos=OJOS["marron"])
TRAJES["aventurero_rojo"] = _variante(
    "aventurero", nombre="Aventurero (tinte rojo)",
    partes=_con_partes("aventurero", {"tunica_verde": "tunica_roja", "pantalon_pardo": "pantalon_gris"}),
    bajo=("tunica_roja", 2), tocado=("PELO_CORTO", "pelo_rubio", None), ojos=OJOS["verde"])
TRAJES["aventurero_pardo"] = _variante(
    "aventurero", nombre="Aventurero (tinte pardo)",
    partes=_con_partes("aventurero", {"tunica_verde": "tunica_parda", "pantalon_pardo": "pantalon_oliva"}),
    bajo=("tunica_parda", 2), tocado=("PELO_CORTO", "pelo_pelirrojo", None), piel="piel_morena",
    ojos=OJOS["marron"])
TRAJES["cultista_carcelero"] = _variante(
    "cultista", nombre="Carcelero del culto",
    partes=_con_partes("cultista", {"habito_purpura": "habito_gris"}),
    habito="habito_gris", tocado=("CAPUCHA", "lana_gris", None), cinturon=("cuero_oscuro", "acero", 0))
TRAJES["aldeana"] = {
    "nombre": "Aldeana",
    "partes": {"t": "vestido_teja", "a": "vestido_teja", "A": "vestido_teja",
               "p": "vestido_teja", "l": "vestido_teja", "L": "vestido_teja"},
    "habito": "vestido_teja",
    "cinturon": ("lino", None, 0),
    "botas": ("zapato", 0),
    "extras": [delantal("lino")],
    "ojos": OJOS["verde"],
    "tocado": ("PELO_LARGO", "pelo_oscuro", None),
}
