#!/usr/bin/env python3
"""Valida los atlas runtime de sprites contra su manifiesto JSON.

Comprueba lo que el motor da por hecho al cargar un atlas y que no se ve
hasta que un sprite sale cortado o vacio en partida:

  1. la imagen existe y mide columns x frameSize (y rows, si se declara);
  2. todo frame citado (frames, objetos, actores, animaciones) esta dentro
     de la rejilla y no esta vacio;
  3. los ids no se repiten;
  4. en los atlas generados (con "generador"), ningun dibujo toca el borde
     de su celda: con filtrado o redondeo de UV se veria en la celda vecina;
  5. en los atlas de actores, cada animacion usa frames de la fila de su
     actor.

    python3 tools/validar_sprites.py                 # los manifiestos por defecto
    python3 tools/validar_sprites.py a.json b.json   # los que se indiquen

Sale con 1 si hay errores. Solo lee: no toca ningun fichero.
"""
import json
import sys
from pathlib import Path

import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parent.parent
TEX = ROOT / "assets/textures"
POR_DEFECTO = ["personaje.json", "actores_capas.json", "props_p0.json", "pickups_p0.json",
               "boundington_story_actors_idle.json"]


def _frame_size(man):
    if "frameSize" in man:
        return int(man["frameSize"][0]), int(man["frameSize"][1])
    if "frame" in man:  # formato de race_npc_idle.json
        return int(man["frame"]["width"]), int(man["frame"]["height"])
    raise ValueError("el manifiesto no declara frameSize")


def _frames_citados(man):
    """(etiqueta, frame) de todos los frames que el manifiesto promete."""
    citados = []
    frames = man.get("frames")
    if isinstance(frames, dict):
        citados += [(f"frames.{k}", v) for k, v in frames.items()]
    elif isinstance(frames, list):
        citados += [(f"frames[{i}]", e.get("frame")) for i, e in enumerate(frames)]
    for o in man.get("objetos", []):
        citados.append((f"objetos.{o.get('id')}", o.get("frame")))
    for a in man.get("actores", []):
        for anim, lista in a.get("animaciones", {}).items():
            citados += [(f"actores.{a.get('id')}.{anim}", f) for f in lista]
    for anim, lista in man.get("animaciones", {}).items():
        citados += [(f"animaciones.{anim}", f) for f in lista]
    return citados


def _ids(man):
    ids = [o.get("id") for o in man.get("objetos", [])]
    ids += [a.get("id") for a in man.get("actores", [])]
    return ids


def validar(ruta_json):
    """Lista de errores (vacia si el atlas cumple el contrato)."""
    ruta_json = Path(ruta_json)
    nombre = ruta_json.name
    try:
        man = json.loads(ruta_json.read_text(encoding="utf-8"))
    except (OSError, ValueError) as e:
        return [f"{nombre}: no se puede leer ({e})"]
    errores = []
    try:
        fw, fh = _frame_size(man)
    except ValueError as e:
        return [f"{nombre}: {e}"]
    ruta_png = ruta_json.parent / man.get("image", "")
    if not man.get("image") or not ruta_png.is_file():
        return [f"{nombre}: falta la imagen {man.get('image')!r}"]
    img = np.array(Image.open(ruta_png).convert("RGBA"))
    alto, ancho = img.shape[:2]
    cols = int(man.get("columns", 0))
    if cols <= 0 or ancho != cols * fw:
        errores.append(f"{nombre}: la imagen mide {ancho} px de ancho y el manifiesto dice "
                       f"{cols} columnas de {fw}")
        return errores
    filas = int(man.get("rows", alto // fh))
    if alto != filas * fh:
        errores.append(f"{nombre}: la imagen mide {alto} px de alto y el manifiesto dice "
                       f"{filas} filas de {fh}")
        return errores
    total = cols * filas

    def celda(f):
        c, r = (f - 1) % cols, (f - 1) // cols
        return img[r * fh:(r + 1) * fh, c * fw:(c + 1) * fw]

    vistos = set()
    for etiqueta, f in _frames_citados(man):
        if not isinstance(f, int) or not 1 <= f <= total:
            errores.append(f"{nombre}: {etiqueta} cita el frame {f!r}, fuera de 1..{total}")
            continue
        if f in vistos:
            continue
        vistos.add(f)
        a = celda(f)[..., 3] > 0
        if not a.any():
            errores.append(f"{nombre}: {etiqueta} cita el frame {f}, que esta vacio")
        elif man.get("generador") and (a[0].any() or a[-1].any() or a[:, 0].any() or a[:, -1].any()):
            errores.append(f"{nombre}: el frame {f} ({etiqueta}) toca el borde de su celda")

    ids = _ids(man)
    repetidos = sorted({i for i in ids if ids.count(i) > 1})
    if repetidos:
        errores.append(f"{nombre}: ids repetidos {repetidos}")

    for a in man.get("actores", []):
        fila = a.get("fila")
        if not isinstance(fila, int):
            continue
        rango = range((fila - 1) * cols + 1, fila * cols + 1)
        for anim, lista in a.get("animaciones", {}).items():
            fuera = [f for f in lista if f not in rango]
            if fuera:
                errores.append(f"{nombre}: {a.get('id')}.{anim} usa frames {fuera} "
                               f"fuera de su fila {fila}")
    return errores


def main(argv):
    rutas = [Path(p) for p in argv] or [TEX / n for n in POR_DEFECTO]
    errores = []
    for ruta in rutas:
        errores += validar(ruta)
    if errores:
        print("\n".join(errores))
        return 1
    print(f"sprites: {len(rutas)} atlas conformes a su manifiesto")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
