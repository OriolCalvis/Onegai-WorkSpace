"""Pinta ropa por capas sobre el cuerpo base de personaje.png.

Cada pixel del cuerpo tiene un TONO (luz, base, sombra, contorno suave,
contorno duro) y una PARTE (actores_partes). Una prenda es un material de
cinco tonos asignado a unas partes: se conserva el volumen del cuerpo y
el ciclo de caminar, y solo cambia el color. Lo que sobresale de la
silueta (pelo, capuchas, cascos, faldones) se anade despues con plantillas
por direccion (actores_tocados.py) o con reglas por frame (cinturon, bajo, botas).
"""
import numpy as np

# Tonos del cuerpo base -> clase de tono
TONO_BASE = {
    (255, 235, 198): "H",  # luz
    (250, 210, 169): "s",  # base
    (215, 139, 100): "d",  # sombra
    (119, 67, 46): "o",    # contorno suave
    (87, 46, 29): "O",     # contorno duro
    (73, 42, 30): "X",     # contorno del parpado / suela
}
OJO = {  # iris (oscuro -> claro) y blanco/brillo
    (20, 85, 105): "i1", (25, 112, 140): "i2", (26, 124, 185): "i3",
    (173, 209, 229): "w1", (191, 218, 235): "w2", (221, 235, 244): "w3",
}


def hexrgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


class Material:
    """Rampa de cinco tonos: luz, base, sombra, contorno suave, contorno duro."""

    def __init__(self, nombre, luz, base, sombra, contorno, contorno_duro=None):
        self.nombre = nombre
        c = [hexrgb(v) for v in (luz, base, sombra, contorno)]
        cd = hexrgb(contorno_duro) if contorno_duro else tuple(max(0, int(v * 0.72)) for v in c[3])
        self.tono = {"H": c[0], "s": c[1], "d": c[2], "o": c[3], "O": cd, "X": cd}

    def __getitem__(self, t):
        return self.tono[t]


def clasificar(frame_px):
    """Matriz de clases de tono ('' = vacio, 'e:<clave>' = ojo)."""
    h, w = frame_px.shape[:2]
    tono = np.full((h, w), "", dtype="<U4")
    for y in range(h):
        for x in range(w):
            if frame_px[y, x, 3] == 0:
                continue
            rgb = tuple(int(v) for v in frame_px[y, x, :3])
            if rgb in TONO_BASE:
                tono[y, x] = TONO_BASE[rgb]
            elif rgb in OJO:
                tono[y, x] = "e:" + OJO[rgb]
            else:
                raise ValueError(f"color no previsto en el cuerpo base: {rgb} en {x},{y}")
    return tono


def suavizar_tonos(tono, mascara):
    """Quita el detalle anatomico de 1 px dentro de una prenda.

    Un pixel de luz o sombra aislado (sin vecino del mismo tono en cruz)
    dentro de la mascara pasa a tono base. Los contornos no se tocan.
    """
    out = tono.copy()
    h, w = tono.shape
    for y in range(h):
        for x in range(w):
            if not mascara[y, x] or tono[y, x] not in ("H", "d"):
                continue
            t = tono[y, x]
            vecinos = 0
            for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                ny, nx = y + dy, x + dx
                if 0 <= ny < h and 0 <= nx < w and mascara[ny, nx] and tono[ny, nx] == t:
                    vecinos += 1
            if vecinos == 0:
                out[y, x] = "s"
    return out


# --- Tocados (pelo, cascos, capuchas) --------------------------------------

def aplicar_tocado(frame_px, plantillas, direccion, top_frame, mat, mat2=None, piel=None,
                   x0=22, top_quieto=None, ojos=None):
    """Dibuja la plantilla de la direccion sobre el frame (in situ).

    La plantilla esta en coordenadas del frame quieto de su direccion; en
    los frames de paso la cabeza baja 1 px y la plantilla con ella (dy).
    La izquierda usa la plantilla de la derecha en espejo. 'z' y 'Z'
    oscurecen lo que ya hay (la cara bajo una capucha o un ala) sin tocar
    los ojos, que siguen leyendose en la sombra.
    """
    espejo = direccion == "izquierda"
    clave = "derecha" if espejo else direccion
    fila0, filas = plantillas[clave]
    dy = top_frame - top_quieto[clave]
    for i, texto in enumerate(filas):
        y = fila0 + i + dy
        for j, c in enumerate(texto):
            if c == ".":
                continue
            x = x0 + j
            if espejo:
                x = 63 - x
            if not (0 <= x < 64 and 0 <= y < 64):
                continue
            if c == "x":
                frame_px[y, x] = (0, 0, 0, 0)
                continue
            if c in "zZ":
                if frame_px[y, x, 3] == 0:
                    continue
                rgb0 = tuple(int(v) for v in frame_px[y, x, :3])
                if rgb0 in OJO or (ojos is not None and ojos[y, x]):
                    continue
                # la sombra se tine con el material (una capucha morada da
                # sombra morada; un ala de acero, sombra azulada)
                if c == "Z":  # sombra profunda: el interior de la capucha
                    frame_px[y, x, :3] = mat["O"]
                    continue
                k = 0.55
                sombra = mat["d"]
                frame_px[y, x, :3] = [int(round(a * (1 - k) + b * k)) for a, b in zip(rgb0, sombra)]
                continue
            if c in "12345":
                rgb = mat[{"1": "H", "2": "s", "3": "d", "4": "O", "5": "o"}[c]]
            elif c in "6789":
                rgb = mat2[{"6": "H", "7": "s", "8": "d", "9": "O"}[c]]
            elif c in "kK":
                rgb = piel["d"] if c == "k" else piel["o"]
            else:
                raise ValueError(f"caracter de plantilla desconocido {c!r}")
            frame_px[y, x, :3] = rgb
            frame_px[y, x, 3] = 255


# --- Prendas ---------------------------------------------------------------

def fila_cinturon(lab):
    ys = np.nonzero((lab == "p").any(axis=1))[0]
    return int(ys.min()) if len(ys) else None


def top_pie(lab, etiqueta):
    ys = np.nonzero((lab == etiqueta).any(axis=1))[0]
    return int(ys.min()) if len(ys) else None


def _es_contorno(t):
    return t in ("o", "O", "X")


def vestir(frame_px, lab, direccion, traje, materiales, plantillas, top_quieto):
    """Devuelve una copia del frame con el traje puesto.

    traje (dict):
      partes    {etiqueta: material}  prendas que siguen la silueta
      bajo      (material, filas)     faldon de la prenda del torso bajo el cinturon
      habito    material              faldon hasta los tobillos que rellena entre las piernas
      cinturon  (material, material_hebilla|None, cabo)
      botas     (material, filas_de_cana)
      piel      material de piel (None = la del cuerpo base)
      ojos      {clase_iris: (r, g, b)}
      extras    [funcion(ctx)]        correas, tabardos, chalecos...
      tocado    (plantilla, material, material2|None)
    """
    px = frame_px.copy()
    tono = clasificar(px)
    ojos = np.char.startswith(tono, "e:")
    cint = fila_cinturon(lab)
    mat = {}  # (y, x) -> Material de la prenda que cubre el pixel

    for y in range(64):
        for x in range(64):
            e = lab[y, x]
            if e and e in traje.get("partes", {}):
                mat[(y, x)] = materiales[traje["partes"][e]]
    if "bajo" in traje and cint is not None:
        m, filas = traje["bajo"]
        for y in range(cint + 1, cint + 1 + filas):
            for x in range(64):
                if lab[y, x] in ("p", "l", "L"):
                    mat[(y, x)] = materiales[m]
    if "botas" in traje:
        m, cana = traje["botas"]
        for pierna, pie in (("l", "f"), ("L", "F")):
            tp = top_pie(lab, pie)
            if tp is None:
                continue
            for y in range(tp - cana, 64):
                for x in range(64):
                    if lab[y, x] in (pierna, pie):
                        mat[(y, x)] = materiales[m]

    # tonos suavizados por prenda (quita el detalle anatomico de 1 px)
    for m in {id(v): v for v in mat.values()}.values():
        mask = np.zeros(lab.shape, bool)
        for (y, x), v in mat.items():
            if v is m:
                mask[y, x] = True
        tono = np.where(mask, suavizar_tonos(tono, mask), tono)
    for (y, x), m in mat.items():
        t = tono[y, x]
        if t and not t.startswith("e:"):
            px[y, x, :3] = m[t]

    # piel descubierta y ojos
    if traje.get("piel"):
        mp = materiales[traje["piel"]]
        for y in range(64):
            for x in range(64):
                t = tono[y, x]
                if lab[y, x] and (y, x) not in mat and t and not t.startswith("e:"):
                    px[y, x, :3] = mp[t]
    for y, x in zip(*np.nonzero(ojos)):
        clase = tono[y, x][2:]
        if clase in traje.get("ojos", {}):
            px[y, x, :3] = traje["ojos"][clase]

    ctx = {"px": px, "lab": lab, "tono": tono, "dir": direccion, "mat": materiales,
           "cint": cint, "cubre": mat, "traje": traje}
    if "habito" in traje and cint is not None:
        habito(ctx, materiales[traje["habito"]])
    if "cinturon" in traje and cint is not None:
        cinturon(ctx, *traje["cinturon"])
    for fn in traje.get("extras", []):
        fn(ctx)

    if "tocado" in traje:
        nombre, m1, m2 = traje["tocado"]
        top = int(np.nonzero(frame_px[:, :, 3].any(axis=1))[0].min())
        piel = materiales[traje["piel"]] if traje.get("piel") else PIEL_BASE
        aplicar_tocado(px, plantillas[nombre], direccion, top, materiales[m1],
                       materiales[m2] if m2 else None, piel, top_quieto=top_quieto, ojos=ojos)
    return px


def pintar(ctx, y, x, m, t):
    ctx["px"][y, x, :3] = m[t]
    ctx["px"][y, x, 3] = 255


def cinturon(ctx, material, hebilla=None, cabo=0):
    """Una fila de cuero (o cuerda) sobre la linea del cinturon."""
    lab, tono, cint, d = ctx["lab"], ctx["tono"], ctx["cint"], ctx["dir"]
    mc = ctx["mat"][material]
    xs = [x for x in range(64) if lab[cint, x] in ("p", "t")]
    if not xs:
        return
    for x in xs:
        t = tono[cint, x]
        pintar(ctx, cint, x, mc, "O" if _es_contorno(t) else ("d" if t == "d" else "s"))
    interior = [x for x in xs if not _es_contorno(tono[cint, x])]
    if not interior or d == "arriba":
        return
    if d == "abajo":
        hx = interior[len(interior) // 2]
    elif d == "derecha":
        hx = interior[-1]
    else:
        hx = interior[0]
    if hebilla:
        pintar(ctx, cint, hx, ctx["mat"][hebilla], "H")
    for k in range(1, cabo + 1):  # cabo de la cuerda colgando
        y = cint + k
        if y < 64 and ctx["px"][y, hx, 3]:
            pintar(ctx, y, hx, mc, "s" if k < cabo else "d")


def habito(ctx, m, vuelo=1):
    """Faldon hasta los tobillos: rellena el hueco entre las piernas.

    La tela del hueco es continua (tono base) con un pliegue central en
    sombra; la silueta se ensancha 'vuelo' px en la mitad baja.
    """
    lab, tono, cint = ctx["lab"], ctx["tono"], ctx["cint"]
    pies = [v for v in (top_pie(lab, "f"), top_pie(lab, "F")) if v is not None]
    bajo = min(pies) if pies else 63
    alto = max(1, bajo - cint)
    for y in range(cint + 1, bajo + 1):
        xs = [x for x in range(64) if lab[y, x] in ("p", "l", "L", "f", "F")]
        if not xs:
            continue
        ens = vuelo if (y - cint) * 2 >= alto else 0
        x0, x1 = min(xs) - ens, max(xs) + ens
        huecos = [x for x in range(x0 + 1, x1) if lab[y, x] not in ("p", "l", "L", "f", "F")]
        pliegue = huecos[len(huecos) // 2] if huecos else None
        for x in range(x0, x1 + 1):
            if x in (x0, x1) or y == bajo:
                t = "O"
            elif x == pliegue:
                t = "d"
            elif lab[y, x] in ("p", "l", "L", "f", "F") and tono[y, x] in ("H", "s", "d"):
                t = tono[y, x]
            else:
                t = "s"
            pintar(ctx, y, x, m, t)
            ctx["cubre"][(y, x)] = m


class _PielBase:
    tono = {"H": (255, 235, 198), "s": (250, 210, 169), "d": (215, 139, 100),
            "o": (119, 67, 46), "O": (87, 46, 29), "X": (73, 42, 30)}

    def __getitem__(self, t):
        return self.tono[t]


PIEL_BASE = _PielBase()
