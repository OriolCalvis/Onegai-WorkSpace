#!/usr/bin/env python3
"""Genera el atlas runtime de actores andando: ropa por capas sobre personaje.png.

personaje.png es un cuerpo base desnudo que ya camina en cuatro
direcciones (tres frames por direccion). Este generador lo viste: cada
pixel del cuerpo lleva una etiqueta de parte (actores_partes.py) y un tono
(luz, base, sombra, contorno); una prenda asigna un material de cinco tonos
a unas partes, de modo que la ropa sigue el ciclo de caminar pixel a pixel.
Pelo, capuchas y cascos, que sobresalen de la silueta, se pintan con una
plantilla por direccion (actores_tocados.py). Los trajes son datos
(actores_trajes.py): anadir un PNJ es anadir una entrada, no dibujar 12
frames.

    python3 tools/gen_actores_capas.py            # PNG + JSON
    python3 tools/gen_actores_capas.py --vista    # + out/revision_actores_capas.{png,gif}

Salida: assets/textures/actores_capas.{png,json} y el manifiesto del
cuerpo base assets/textures/personaje.json (su reparto real de frames).
"""
import argparse
import json
from pathlib import Path

import numpy as np
from PIL import Image

import actores_partes as partes
import actores_pintura as pintura
import actores_tocados as tocados
import actores_trajes as trajes

ROOT = Path(__file__).resolve().parent.parent
TEX = ROOT / "assets/textures"
BASE = TEX / "personaje.png"
FRAME = 64
COLUMNAS = 12

# Orden de filas del atlas. El jugador va primero.
FILAS = ["aventurero", "aventurero_azul", "aventurero_rojo", "aventurero_pardo",
         "guardia", "aldeano", "aldeana", "cultista", "cultista_carcelero"]

USOS = {  # para que sirve cada fila (documentacion del manifiesto)
    "aventurero": "Jugador: sustituto de personaje.png como sprite del protagonista.",
    "aventurero_azul": "Tinte del aventurero: companero o PNJ viajero.",
    "aventurero_rojo": "Tinte del aventurero: companero o PNJ viajero.",
    "aventurero_pardo": "Tinte del aventurero: companero o PNJ viajero.",
    "guardia": "Guardia que patrulla (puertas y zonas de riesgo).",
    "aldeano": "Parroquiano, tendero o vecino que pasea.",
    "aldeana": "Parroquiana, tabernera o vecina que pasea.",
    "cultista": "Perdido encapuchado: saqueador o fanatico que se mueve.",
    "cultista_carcelero": "Carcelero del culto.",
}

# Reparto de frames de UNA fila (igual en personaje.png y en cada fila del atlas):
# arriba 1-3, derecha 4-6, abajo 7-9, izquierda 10-12; en cada tramo, el del
# medio es el quieto. El ciclo de caminar es paso, quieto, paso, quieto.
DIRECCIONES = {"arriba": [1, 2, 3], "derecha": [4, 5, 6], "abajo": [7, 8, 9],
               "izquierda": [10, 11, 12]}
ANIMACIONES = {
    "idle": [8], "idle_down": [8], "idle_up": [2], "idle_right": [5], "idle_left": [11],
    "walk_down": [7, 8, 9, 8], "walk_up": [1, 2, 3, 2],
    "walk_right": [4, 5, 6, 5], "walk_left": [10, 11, 12, 11],
}

NOTA_REPARTO = (
    "Frames 1-based. Cada fila: arriba 1-3, derecha 4-6, abajo 7-9, izquierda 10-12 "
    "(paso, quieto, paso). OJO: Application.cpp registra hoy personaje.png como "
    "walk_down {1,2,3,4}, walk_up {5..8}, walk_right/left {9..12} e idle {1}, que no es "
    "el reparto real de la hoja: el jugador aparece de espaldas al quedarse quieto y "
    "'camina hacia abajo' mostrando la espalda. El reparto correcto es el de "
    "'animaciones'. TextureManager invierte los PNG al cargarlos: en un atlas de varias "
    "filas la region del frame f es defineRegion(f, (f-1) % columns, "
    "rows - 1 - (f-1) / columns), como race_npc_idle.")


def vestir_fila(frames, labs, ident):
    traje = trajes.TRAJES[ident]
    plantillas = {"PELO_CORTO": tocados.PELO_CORTO, "PELO_LARGO": tocados.PELO_LARGO,
                  "CAPUCHA": tocados.CAPUCHA, "CHAPEL": tocados.CHAPEL}
    return [pintura.vestir(frames[f - 1], labs[f], partes.DIRECCION[f], traje,
                           trajes.MATERIALES, plantillas, tocados.TOP_QUIETO)
            for f in range(1, 13)]


def comprobar_frame(px, ident, f):
    """Nada puede tocar el borde de la celda: se veria en el frame vecino."""
    a = px[..., 3] > 0
    if a[0].any() or a[-1].any() or a[:, 0].any() or a[:, -1].any():
        raise SystemExit(f"{ident} frame {f}: el dibujo toca el borde de la celda")


def animaciones_de_fila(fila):
    base = fila * COLUMNAS
    return {nombre: [base + f for f in fr] for nombre, fr in ANIMACIONES.items()}


def generar(vista=False, salida=TEX):
    salida = Path(salida)
    frames, labs, errores = partes.construir(BASE)
    if errores:
        raise SystemExit("mapa de partes incompleto:\n  " + "\n  ".join(errores))
    filas = []
    for ident in FILAS:
        fila = vestir_fila(frames, labs, ident)
        for f, px in enumerate(fila, 1):
            comprobar_frame(px, ident, f)
        filas.append(fila)
    alto = len(FILAS) * FRAME
    img = np.zeros((alto, COLUMNAS * FRAME, 4), np.uint8)
    for r, fila in enumerate(filas):
        for c, px in enumerate(fila):
            img[r * FRAME:(r + 1) * FRAME, c * FRAME:(c + 1) * FRAME] = px
    Image.fromarray(img, "RGBA").save(salida / "actores_capas.png", optimize=True)

    actores = []
    for r, ident in enumerate(FILAS):
        actores.append({
            "id": ident,
            "nombre": trajes.TRAJES[ident]["nombre"],
            "fila": r + 1,
            "primerFrame": r * COLUMNAS + 1,
            "uso": USOS[ident],
            "animaciones": animaciones_de_fila(r),
        })
    manifiesto = {
        "_nota": ("Atlas runtime de actores con caminar en 4 direcciones. Generado por "
                  "tools/gen_actores_capas.py vistiendo personaje.png: no editar a mano. "
                  + NOTA_REPARTO),
        "estado": "runtime",
        "generador": "tools/gen_actores_capas.py",
        "cuerpoBase": "personaje.png",
        "image": "actores_capas.png",
        "frameSize": [FRAME, FRAME],
        "columns": COLUMNAS,
        "rows": len(FILAS),
        "anclaje": {"pies": "centro inferior de la celda", "filaPies": 60,
                    "dibujo": "64x64 con characterAnchor(), igual que personaje.png"},
        "direcciones": DIRECCIONES,
        "animacionesPorFila": ANIMACIONES,
        "actores": actores,
    }
    (salida / "actores_capas.json").write_text(
        json.dumps(manifiesto, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")

    base = {
        "_nota": ("Contrato del cuerpo base: 12 frames de 64x64 en una fila. " + NOTA_REPARTO),
        "estado": "runtime temporal (fallback de actores sin hoja propia)",
        "image": "personaje.png",
        "frameSize": [FRAME, FRAME],
        "columns": COLUMNAS,
        "rows": 1,
        "direcciones": DIRECCIONES,
        "animaciones": ANIMACIONES,
        "espejos": {"3": "espejo de 1", "9": "espejo de 7", "10": "espejo de 4",
                    "11": "espejo de 5", "12": "espejo de 6"},
        "vestidoEn": "actores_capas.png (tools/gen_actores_capas.py)",
    }
    (salida / "personaje.json").write_text(
        json.dumps(base, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
    print(f"{_ruta(salida / 'actores_capas.png')}: {len(FILAS)} actores x 12 frames "
          f"({COLUMNAS * FRAME}x{alto}), + actores_capas.json y personaje.json")
    if vista:
        revision(filas, labs)


def _ruta(p):
    try:
        return Path(p).resolve().relative_to(ROOT)
    except ValueError:
        return p


def revision(filas, labs, escala=3):
    """Hoja estatica (con el mapa de partes) y GIF de los ciclos de caminar."""
    out = ROOT / "out"
    out.mkdir(parents=True, exist_ok=True)
    fondo = (150, 158, 166, 255)
    recorte = (14, 14, 50, 64)  # la zona util de cada frame
    rw, rh = recorte[2] - recorte[0], recorte[3] - recorte[1]

    def celda(px):
        im = Image.fromarray(px).crop(recorte)
        base = Image.new("RGBA", im.size, fondo)
        base.alpha_composite(im)
        return base.resize((rw * escala, rh * escala), Image.NEAREST)

    colores = {"h": (240, 200, 60), "n": (255, 140, 0), "t": (60, 170, 80), "p": (30, 90, 160),
               "a": (200, 60, 60), "A": (240, 120, 120), "m": (130, 30, 130),
               "M": (220, 110, 220), "l": (60, 60, 200), "L": (120, 160, 255),
               "f": (90, 50, 20), "F": (170, 120, 70)}
    mapa = []
    for f in range(1, 13):
        px = np.zeros((FRAME, FRAME, 4), np.uint8)
        for (y, x), e in np.ndenumerate(labs[f]):
            if e:
                px[y, x] = colores[e] + (255,)
        mapa.append(px)
    hoja = Image.new("RGBA", (12 * rw * escala, (len(filas) + 1) * rh * escala), (58, 62, 70, 255))
    for c, px in enumerate(mapa):
        hoja.paste(celda(px), (c * rw * escala, 0))
    for r, fila in enumerate(filas, 1):
        for c, px in enumerate(fila):
            hoja.paste(celda(px), (c * rw * escala, r * rh * escala))
    hoja.save(out / "revision_actores_capas.png")

    orden = ["walk_down", "walk_right", "walk_up", "walk_left"]
    cuadros = []
    for anim in orden:
        for f in ANIMACIONES[anim] * 2:
            cuadro = Image.new("RGBA", (len(filas) * rw * escala, rh * escala), fondo)
            for r, fila in enumerate(filas):
                cuadro.paste(celda(fila[f - 1]), (r * rw * escala, 0))
            cuadros.append(cuadro.convert("RGB").quantize(colors=255, method=Image.Quantize.MEDIANCUT,
                                                          dither=Image.Dither.NONE))
    cuadros[0].save(out / "revision_actores_capas.gif", save_all=True, append_images=cuadros[1:],
                    duration=180, loop=0, optimize=False, disposal=2)
    print("revision: out/revision_actores_capas.png, out/revision_actores_capas.gif")


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--vista", action="store_true",
                    help="escribe out/revision_actores_capas.png y .gif")
    ap.add_argument("--salida", default=str(TEX),
                    help="carpeta de salida (por defecto assets/textures)")
    args = ap.parse_args()
    generar(args.vista, args.salida)
