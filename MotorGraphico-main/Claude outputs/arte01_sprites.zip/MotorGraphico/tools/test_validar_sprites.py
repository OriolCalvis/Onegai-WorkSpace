#!/usr/bin/env python3
"""Pruebas del validador de atlas y de los generadores de sprites ARTE-01.

    python3 tools/test_validar_sprites.py

Cada regla del validador tiene su caso que la hace fallar (si una regla se
borra, su prueba se pone roja). Ademas se comprueba que los atlas del repo
cumplen el contrato, que el mapa de partes cubre el cuerpo base entero y
que los PNG versionados son exactamente lo que producen los generadores.
"""
import hashlib
import json
import sys
import tempfile
import unittest
from pathlib import Path

import numpy as np
from PIL import Image

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import validar_sprites as vs  # noqa: E402

TEX = HERE.parent / "assets/textures"


def _atlas(carpeta, frames, tam=8, columnas=2, filas=1, nombre="a.png"):
    """PNG de columnas x filas celdas; 'frames' = {frame: (x0, y0, x1, y1) opaco}."""
    img = np.zeros((filas * tam, columnas * tam, 4), np.uint8)
    for f, (x0, y0, x1, y1) in frames.items():
        c, r = (f - 1) % columnas, (f - 1) // columnas
        img[r * tam + y0:r * tam + y1, c * tam + x0:c * tam + x1] = (200, 100, 50, 255)
    Image.fromarray(img, "RGBA").save(Path(carpeta) / nombre)


def _manifiesto(carpeta, datos, nombre="a.json"):
    ruta = Path(carpeta) / nombre
    ruta.write_text(json.dumps(datos), encoding="utf-8")
    return ruta


class ValidadorTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.dir = self.tmp.name
        _atlas(self.dir, {1: (2, 2, 6, 7), 2: (1, 1, 7, 7)})
        self.base = {"image": "a.png", "frameSize": [8, 8], "columns": 2, "rows": 1,
                     "generador": "prueba", "frames": {"uno": 1, "dos": 2}}

    def tearDown(self):
        self.tmp.cleanup()

    def test_atlas_conforme_no_da_errores(self):
        self.assertEqual(vs.validar(_manifiesto(self.dir, self.base)), [])

    def test_frame_fuera_de_la_rejilla(self):
        self.base["frames"]["tres"] = 3
        errores = vs.validar(_manifiesto(self.dir, self.base))
        self.assertTrue(any("fuera de 1..2" in e for e in errores), errores)

    def test_frame_vacio(self):
        _atlas(self.dir, {1: (2, 2, 6, 7)})  # el 2 queda vacio
        errores = vs.validar(_manifiesto(self.dir, self.base))
        self.assertTrue(any("vacio" in e for e in errores), errores)

    def test_dibujo_que_toca_el_borde_en_atlas_generado(self):
        _atlas(self.dir, {1: (2, 2, 6, 7), 2: (0, 1, 7, 7)})
        errores = vs.validar(_manifiesto(self.dir, self.base))
        self.assertTrue(any("toca el borde" in e for e in errores), errores)

    def test_el_borde_solo_se_exige_a_los_atlas_generados(self):
        _atlas(self.dir, {1: (2, 2, 6, 7), 2: (0, 1, 7, 8)})
        del self.base["generador"]  # los pies de un retrato pueden llegar abajo
        self.assertEqual(vs.validar(_manifiesto(self.dir, self.base)), [])

    def test_imagen_que_no_mide_lo_declarado(self):
        self.base["columns"] = 3
        errores = vs.validar(_manifiesto(self.dir, self.base))
        self.assertTrue(any("de ancho" in e for e in errores), errores)

    def test_falta_la_imagen(self):
        self.base["image"] = "no_existe.png"
        errores = vs.validar(_manifiesto(self.dir, self.base))
        self.assertTrue(any("falta la imagen" in e for e in errores), errores)

    def test_ids_repetidos(self):
        self.base["objetos"] = [{"id": "x", "frame": 1}, {"id": "x", "frame": 2}]
        errores = vs.validar(_manifiesto(self.dir, self.base))
        self.assertTrue(any("repetidos" in e for e in errores), errores)

    def test_animacion_fuera_de_la_fila_del_actor(self):
        _atlas(self.dir, {1: (2, 2, 6, 7), 2: (2, 2, 6, 7), 3: (2, 2, 6, 7), 4: (2, 2, 6, 7)},
               filas=2)
        self.base["rows"] = 2
        self.base["actores"] = [{"id": "a", "fila": 1, "animaciones": {"walk": [1, 2, 3]}}]
        errores = vs.validar(_manifiesto(self.dir, self.base))
        self.assertTrue(any("fuera de su fila" in e for e in errores), errores)

    def test_formato_de_race_npc_idle(self):
        datos = {"image": "a.png", "frame": {"width": 8, "height": 8}, "columns": 2,
                 "frames": [{"raceId": "r1", "frame": 1}, {"raceId": "r2", "frame": 2}]}
        self.assertEqual(vs.validar(_manifiesto(self.dir, datos)), [])


@unittest.skipUnless((TEX / "actores_capas.json").is_file(), "sin los atlas de ARTE-01")
class AtlasDelRepoTests(unittest.TestCase):
    def test_los_atlas_del_repo_cumplen_su_manifiesto(self):
        errores = []
        for nombre in vs.POR_DEFECTO:
            if (TEX / nombre).is_file():
                errores += vs.validar(TEX / nombre)
        self.assertEqual(errores, [])

    def test_el_jugador_mira_a_camara_al_quedarse_quieto(self):
        # personaje.png: arriba 1-3, derecha 4-6, abajo 7-9, izquierda 10-12
        man = json.loads((TEX / "personaje.json").read_text(encoding="utf-8"))
        self.assertEqual(man["animaciones"]["idle"], [8])
        self.assertEqual(man["animaciones"]["walk_down"], [7, 8, 9, 8])
        self.assertEqual(man["animaciones"]["walk_left"], [10, 11, 12, 11])

    def test_mapa_de_partes_cubre_el_cuerpo_base(self):
        import actores_partes
        _frames, labs, errores = actores_partes.construir(TEX / "personaje.png")
        self.assertEqual(errores, [])
        self.assertEqual(sorted(labs), list(range(1, 13)))


def _md5(ruta):
    return hashlib.md5(Path(ruta).read_bytes()).hexdigest()


@unittest.skipUnless((TEX / "actores_capas.png").is_file(), "sin los atlas de ARTE-01")
class GeneradoresTests(unittest.TestCase):
    """Lo versionado es exactamente lo que sale del generador: nadie lo retoca a mano."""

    def test_actores_capas_es_reproducible(self):
        import gen_actores_capas
        with tempfile.TemporaryDirectory() as tmp:
            gen_actores_capas.generar(salida=tmp)
            for nombre in ("actores_capas.png", "actores_capas.json", "personaje.json"):
                self.assertEqual(_md5(Path(tmp) / nombre), _md5(TEX / nombre), nombre)

    def test_props_y_pickups_son_reproducibles(self):
        import gen_props_p0
        with tempfile.TemporaryDirectory() as tmp:
            gen_props_p0.generar(salida=tmp)
            for nombre in ("props_p0.png", "props_p0.json", "pickups_p0.png", "pickups_p0.json"):
                self.assertEqual(_md5(Path(tmp) / nombre), _md5(TEX / nombre), nombre)


if __name__ == "__main__":
    unittest.main(verbosity=2)
