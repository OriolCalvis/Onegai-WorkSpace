# Actores andando por capas

`actores_capas.png` es un atlas **runtime** de 12 columnas × 9 filas de
64×64. Cada fila es un actor completo que camina en cuatro direcciones.
Lo genera `tools/gen_actores_capas.py` vistiendo el cuerpo base
`personaje.png`; su contrato está en `actores_capas.json`. **No se edita a
mano**: se cambia el traje y se regenera.

```sh
python3 tools/gen_actores_capas.py            # PNG + JSON
python3 tools/gen_actores_capas.py --vista    # + out/revision_actores_capas.{png,gif}
python3 tools/validar_sprites.py              # comprueba atlas contra manifiesto
```

## Reparto de frames de cada fila

Es el reparto **real** de `personaje.png`, que el atlas conserva:

| Frames de la fila | Dirección | Quieto |
| ---: | --- | ---: |
| 1-3 | arriba (de espaldas) | 2 |
| 4-6 | derecha | 5 |
| 7-9 | abajo (de frente) | 8 |
| 10-12 | izquierda | 11 |

| Animación | Frames de la fila |
| --- | --- |
| `idle` | 8 |
| `idle_up` / `idle_right` / `idle_left` | 2 / 5 / 11 |
| `walk_down` | 7, 8, 9, 8 |
| `walk_up` | 1, 2, 3, 2 |
| `walk_right` | 4, 5, 6, 5 |
| `walk_left` | 10, 11, 12, 11 |

Frame global = (fila − 1) × 12 + frame de la fila. El manifiesto trae ya
calculadas las animaciones de cada actor.

## Filas

| Fila | `id` | Primer frame | Uso |
| ---: | --- | ---: | --- |
| 1 | `aventurero` | 1 | Jugador: sustituto de `personaje.png` como protagonista. |
| 2 | `aventurero_azul` | 13 | Tinte: compañero o PNJ viajero. |
| 3 | `aventurero_rojo` | 25 | Tinte: compañero o PNJ viajero. |
| 4 | `aventurero_pardo` | 37 | Tinte: compañero o PNJ viajero. |
| 5 | `guardia` | 49 | Guardia de Boundington que patrulla. |
| 6 | `aldeano` | 61 | Parroquiano, tendero o vecino que pasea. |
| 7 | `aldeana` | 73 | Parroquiana, tabernera o vecina que pasea. |
| 8 | `cultista` | 85 | Perdido encapuchado que se mueve. |
| 9 | `cultista_carcelero` | 97 | Carcelero del culto. |

El atlas de historia (`boundington_story_actors_idle.png`) sigue siendo el
retrato quieto de Luisarda, Ben, Griffin y compañía. Estas filas sirven a
los PNJ y enemigos que **se mueven**, y a los que hoy caen en el
«bebé» de `personaje.png` por no tener hoja propia.

## Cómo se hace

1. **Mapa de partes** (`tools/actores_partes.py`): cada píxel opaco de
   `personaje.png` está etiquetado como cabeza, cuello, torso, pelvis,
   brazo, mano, pierna o pie. Solo 7 de los 12 frames son dibujos
   distintos; los otros 5 son espejos exactos y se derivan. El generador
   falla si un píxel del cuerpo se queda sin etiqueta.
2. **Prendas** (`tools/actores_pintura.py`): un material de cinco tonos
   (luz, base, sombra, contorno suave, contorno duro) se aplica a unas
   partes conservando el tono de cada píxel, así que la ropa sigue el
   ciclo de caminar píxel a píxel. El faldón, las botas, el cinturón y el
   hábito largo son reglas por frame.
3. **Tocados** (`tools/actores_tocados.py`): pelo corto, melena, capucha y
   chapel de hierro sobresalen de la silueta, así que se dibujan con una plantilla
   por dirección; la izquierda es el espejo de la derecha.
4. **Trajes** (`tools/actores_trajes.py`): son datos. Un traje nuevo es
   una entrada con materiales, no doce frames dibujados.

### Añadir un actor

1. Si hace falta, un material nuevo en `MATERIALES` (cinco colores).
2. Una entrada en `TRAJES` (partes, faldón, cinturón, botas, piel, ojos,
   extras y tocado). `_variante()` copia un traje cambiando colores.
3. Su `id` en `FILAS` de `gen_actores_capas.py`, regenerar y validar.

## Pendiente de cablear en el motor

Por decisión de Oriol (25/09) esta entrega es **arte + manifiestos**: el
motor todavía no carga este atlas. Al cablearlo, no en `Application.cpp`
(está por encima del techo de 500 líneas), sino en una clase que lea los
manifiestos:

```cpp
// TextureManager invierte los PNG al cargarlos: en un atlas de varias
// filas la fila se invierte, igual que en race_npc_idle.
for (int f = 1; f <= columns * rows; ++f)
    atlas->defineRegion(f, (f - 1) % columns, rows - 1 - (f - 1) / columns);
// Animaciones: las de "animaciones" de cada actor en actores_capas.json.
```

### El fallo que esto destapa en `personaje.png`

`Application::init` registra hoy `walk_down {1,2,3,4}`, `walk_up {5..8}`,
`walk_right` y `walk_left {9..12}` e `idle {1}`. La hoja real es arriba,
derecha, abajo, izquierda con tres frames cada una. Resultado: **el
jugador se queda de espaldas** cuando está quieto, «camina hacia abajo»
enseñando la espalda y mezcla vistas en cada ciclo. El reparto correcto
está en `personaje.json` y lo comprueba `tools/test_validar_sprites.py`.

## Escala

El cuerpo base mide 40 px de alto (pies en la fila 60). Los retratos del
atlas de historia miden unos 58 px. Esa diferencia ya existía entre el
jugador y los PNJ de Boundington; unificarla (escala visual por objeto o
un cuerpo base más alto) es una decisión de producto pendiente.
